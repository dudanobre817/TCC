Object.assign(views, {

      /* ================= SOLICITAÇÕES ================= */

      requests: () => {

        const n = (s) =>
          S.requests.filter(
            (r) => r.status === s
          ).length;

        return pg(`

          <div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">

            ${stat(
          "clipboard-list",
          "Total",
          S.requests.length
        )}

            ${stat(
          "clock",
          "Em análise",
          n("Em análise")
        )}

            ${stat(
          "check-circle-2",
          "Aprovadas",
          n("Aprovada")
        )}

            ${stat(
          "x-circle",
          "Recusadas",
          n("Recusada")
        )}

          </div>


          <div class="${CARD} p-5">

            ${ttl(
          "clipboard-list",
          "Lista de solicitações"
        )}

            <div class="mt-4">

              ${table(
          [
            [
              "Nº",
              (r) => esc(r.numero)
            ],
            [
              "Espaço",
              (r) => esc(r.espaco)
            ],
            [
              "Tipo",
              (r) => esc(r.tipo)
            ],
            [
              "Descrição",
              (r) => esc(r.descricao)
            ],
            [
              "Data",
              (r) => esc(r.criadaEm)
            ],
            [
              "Data da reserva",
              (r) => esc(r.dataReserva)
            ],
            [
              "Status",
              (r) => badge(r.status)
            ],
            [
              "Ações",
              () => `
                      <button
                        type="button"
                        class="text-[#1E2A78] hover:text-[#C8102E]"
                      >
                        ${ic("eye")}
                      </button>
                    `
            ]
          ],
          S.requests,
          empty(
            "clipboard-list",
            "Nenhuma solicitação encontrada",
            "Suas solicitações aparecerão aqui quando forem enviadas."
          )
        )}

            </div>

          </div>
        `);
      },

});
