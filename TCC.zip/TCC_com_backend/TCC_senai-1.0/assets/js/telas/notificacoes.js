Object.assign(views, {

      /* ================= NOTIFICAÇÕES ================= */

      notifications: () => {

        const t =
          S.ui.ntab || "todas";

        const N = S.notifications;

        const cont = (k) =>
          k === "todas"
            ? N.length
            : N.filter(
              (n) =>
                n.categoria === k
            ).length;

        const lista = N.filter(
          (n) =>
            t === "todas" ||
            n.categoria === t
        );

        return pg(`

          <div class="${CARD} p-5">

            <div class="mb-4 flex flex-wrap items-center justify-between gap-3">

              <div class="flex flex-wrap gap-2">

                ${[
            ["todas", "Todas"],
            [
              "reservas",
              "Reservas"
            ],
            [
              "solicitacoes",
              "Solicitações"
            ],
            ["avisos", "Avisos"]
          ]
            .map(
              ([k, x]) => `
                      <button
                        type="button"
                        data-a="ntab"
                        data-v="${k}"
                        class="flex items-center gap-2 rounded-full border border-[#1E2A78] px-3 py-1 text-sm font-semibold transition ${t === k
                  ? "bg-[#1E2A78] text-white"
                  : "text-[#1E2A78] hover:bg-indigo-50"
                }"
                      >

                        ${x}

                        <span class="rounded-full bg-indigo-100 px-1.5 text-xs text-[#1E2A78]">
                          ${cont(k)}
                        </span>

                      </button>
                    `
            )
            .join("")}

              </div>

              ${btn(
              "Marcar todas como lidas",
              {
                a: "lidas",
                i: "check",
                k: "ghost",
                dis:
                  !N.some(
                    (n) => !n.lida
                  )
              }
            )}

            </div>


            ${lista.length
            ? `
                  <div class="space-y-2">
                    ${lista
              .map(notifItem)
              .join("")}
                  </div>
                `
            : empty(
              "bell",
              "Você não possui notificações",
              "Novas notificações aparecerão aqui."
            )
          }

          </div>
        `);
      }

});
