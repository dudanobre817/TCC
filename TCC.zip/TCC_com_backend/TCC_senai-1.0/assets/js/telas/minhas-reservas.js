Object.assign(views, {

      /* ================= MINHAS RESERVAS ================= */

      reservations: () => {

        const f = S.f;

        const lista = S.reservations.filter(
          (r) =>
            (!f.ft || r.tipo === f.ft) &&
            (!f.fs || r.status === f.fs) &&
            (
              !f.fq ||
              String(r.espaco || "")
                .toLowerCase()
                .includes(
                  String(f.fq).toLowerCase()
                )
            ) &&
            noPeriodo(r, f.fp)
        );

        return pg(`

          <div class="${CARD} grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-5">

            ${select(
          "Período",
          "fp",
          [
            "Este mês",
            "Próximo mês"
          ],
          {
            ph: "Todos",
            r: true
          }
        )}

            ${select(
          "Tipo",
          "ft",
          TIPOS,
          {
            ph: "Todos",
            r: true
          }
        )}

            ${select(
          "Status",
          "fs",
          [
            "Confirmada",
            "Em análise",
            "Cancelada",
            "Recusada"
          ],
          {
            ph: "Todos",
            r: true
          }
        )}

            ${input(
          "Pesquisa",
          "fq",
          {
            icon: "search",
            ph: "Buscar espaço",
            req: false,
            r: true
          }
        )}

            <div class="flex items-end">

              ${btn("Limpar filtros", {
          a: "limpar",
          i: "filter",
          k: "outline",
          c: "w-full"
        })}

            </div>

          </div>


          <div class="grid gap-6 xl:grid-cols-[minmax(0,1fr)_minmax(620px,760px)]">

            <div>

              ${ttl(
          "clock",
          "Suas reservas",
          `<span class="text-xs text-[#6B7280]">Total: ${lista.length}</span>`
        )}

              <div class="mt-3 space-y-3">

                ${lista.length
            ? lista.map(resCard).join("")
            : `
                      <div class="${CARD}">
                        ${empty(
              "calendar-days",
              "Nenhuma reserva encontrada",
              "Você ainda não possui reservas cadastradas.",
              btn("Nova reserva", {
                a: "go",
                v: "new",
                i: "plus"
              })
            )}
                      </div>
                    `
          }

              </div>

            </div>


            ${calendar()}

          </div>

        `);
      },

});
