/* ================================================================
   PAINEL DO ADMINISTRADOR (somente Front-End)
   - Estado local em memória (objeto S). Nada é gravado no navegador.
   - Começa vazio: nenhuma sala, reserva, usuário ou notificação inventada.
   - Dados reais chegam por adminApi (admin_api.js) ou AdminApp.setData().
   - Autenticação real: responsabilidade do Back-End (veja admin_api.js).
   ================================================================ */

(() => {
  "use strict";

  /* ================================================================
     HELPERS
     ================================================================ */

  const $ = (s, r = document) => r.querySelector(s);

  const esc = (s) =>
    String(s ?? "").replace(/[&<>"']/g, (c) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[c]);

  const ic = (n, c = "w-4 h-4") => `<i data-lucide="${n}" class="${c}"></i>`;

  const icons = () => {
    if (window.lucide && typeof lucide.createIcons === "function") lucide.createIcons();
  };

  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

  const pad = (n) => String(n).padStart(2, "0");
  const iso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const parseISO = (s) => new Date(s + "T00:00:00");
  const hojeISO = () => iso(new Date());
  const addDias = (s, n) => { const d = parseISO(s); d.setDate(d.getDate() + n); return iso(d); };
  const addMeses = (s, n) => { const d = parseISO(s); d.setDate(1); d.setMonth(d.getMonth() + n); return iso(d); };
  const min = (hhmm) => { const [h, m] = String(hhmm || "0:0").split(":"); return Number(h) * 60 + Number(m || 0); };

  const fmtData = (v) => {
    if (!v) return "--";
    const d = /^\d{4}-\d{2}-\d{2}$/.test(v) ? parseISO(v) : new Date(v);
    return isNaN(d) ? String(v) : d.toLocaleDateString("pt-BR");
  };

  const fmtDataHora = (v) => {
    if (!v) return "--";
    const d = new Date(v);
    return isNaN(d)
      ? String(v)
      : d.toLocaleDateString("pt-BR") + " às " + d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
  };

  const CARD = "bg-white rounded-2xl border border-[#E5E7EB] shadow-sm";

  const FLD =
    "w-full rounded-xl border border-[#E5E7EB] bg-white px-3 py-2.5 text-sm placeholder:text-[#9CA3AF] transition focus:outline-none focus:border-[#1E2A78] focus:ring-2 focus:ring-[#1E2A78]/20";

  const BLOCOS = ["A", "B", "C"];
  const TIPOS = ["Salas de aula", "Laboratórios", "Espaços de convivência", "Auditório", "Outros"];
  const EQUIP = ["Wi-Fi", "Projetor", "Computadores", "Ventiladores", "Ar-condicionado", "Tomadas", "Quadro branco"];
  const DIAS = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
  const MESES = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
  const STATUS_RESERVA = ["Em análise", "Aprovada", "Recusada", "Cancelada"];
  const TIPOS_HIST = ["Aprovação", "Recusa", "Cancelamento", "Alteração"];

  const STATUS_COR = {
    Aprovada: "bg-green-100 text-green-800",
    Confirmada: "bg-green-100 text-green-800",
    Ativo: "bg-green-100 text-green-800",
    "Em análise": "bg-yellow-100 text-yellow-800",
    Recusada: "bg-rose-100 text-rose-800",
    Cancelada: "bg-rose-100 text-rose-800",
    Inativo: "bg-gray-200 text-gray-700"
  };

  const APROV = (r) => r.status === "Aprovada" || r.status === "Confirmada";
  const PEND = (r) => r.status === "Em análise";
  const mesmaSala = (a, b) =>
    a.salaId !== undefined && b.salaId !== undefined ? String(a.salaId) === String(b.salaId) : a.espaco === b.espaco;

  /* ================================================================
     ESTADO E ARMAZENAMENTO LOCAL DO MODO DE DEMONSTRAÇÃO
     ================================================================ */

  const carregarSalasDemo = () => {
    try { return JSON.parse(localStorage.getItem("admin_demo_salas") || "[]"); } catch { return []; }
  };
  const salvarSalasDemo = () => {
    if (sessionStorage.getItem("admin_demo_mode") === "true") {
      try { localStorage.setItem("admin_demo_salas", JSON.stringify(S.salas)); }
      catch (e) { console.warn("Não foi possível salvar as salas neste navegador.", e); }
    }
  };

  const S = {
    view: "dashboard",
    menu: false,
    sessao: null,

    salas: carregarSalasDemo(),
    reservas: [],
    usuarios: [],
    notificacoes: [],
    historico: [],

    config: {
      dias: [],
      abertura: "",
      fechamento: "",
      duracaoMaxHoras: "",
      antecedenciaMinHoras: "",
      antecedenciaMaxDias: ""
    },

    f: {
      salas: { q: "", bloco: "", tipo: "" },
      solicitacoes: { q: "", status: "", data: "" },
      reservas: { q: "", bloco: "", data: "" },
      usuarios: { q: "", status: "" },
      notificacoes: { aba: "todas" },
      historico: { q: "", tipo: "" },
      cal: { modo: "mes", ref: hojeISO(), sala: "" }
    }
  };

  const autor = () => S.sessao?.nome || "Administrador";

  /* ================================================================
     FEEDBACK: toast, histórico, sincronização
     ================================================================ */

  let toastTimer;

  const toast = (msg, tipo = "ok") => {
    const el = $("#toast-root");
    el.innerHTML = `
      <div role="status" class="pointer-events-auto flex items-center gap-2 rounded-xl px-4 py-3 text-sm font-semibold text-white shadow-lg ${tipo === "err" ? "bg-[#C8102E]" : "bg-[#1E2A78]"}">
        ${ic(tipo === "err" ? "alert-triangle" : "check-circle-2", "w-4 h-4")} ${esc(msg)}
      </div>`;
    icons();
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (el.innerHTML = ""), 3500);
  };

  const sync = (fn) =>
    Promise.resolve()
      .then(fn)
      .catch((err) => {
        console.error("Falha ao sincronizar com o Back-End:", err);
        toast("Não foi possível sincronizar com o servidor.", "err");
      });

  const registrar = (tipo, descricao) => {
    const e = { id: uid(), tipo, descricao, quando: new Date().toISOString(), autor: autor() };
    S.historico.unshift(e);
    sync(() => adminApi.registrarHistorico(e));
  };

  /* ================================================================
     COMPONENTES
     ================================================================ */

  const btn = (t, { a, v = "", i, k = "primary", c = "", type = "button", dis = false, label = "" } = {}) => {
    const K = {
      primary: "bg-[#C8102E] text-white hover:bg-[#A80D25]",
      navy: "bg-[#1E2A78] text-white hover:bg-[#161f5c]",
      outline: "border border-[#1E2A78] text-[#1E2A78] hover:bg-[#1E2A78]/5",
      danger: "bg-rose-100 text-rose-800 hover:bg-rose-200",
      ghost: "text-[#6B7280] hover:bg-gray-100"
    }[k];

    return `<button type="${type}" ${a ? `data-a="${a}" data-v="${esc(v)}"` : ""} ${dis ? "disabled" : ""} ${label ? `aria-label="${esc(label)}" title="${esc(label)}"` : ""}
      class="inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition active:scale-[.98] disabled:pointer-events-none disabled:opacity-50 ${K} ${c}">
      ${i ? ic(i) : ""}${t}</button>`;
  };

  const iconBtn = (icon, label, a, v, tone = "text-[#1E2A78] hover:bg-[#1E2A78]/10") =>
    `<button type="button" data-a="${a}" data-v="${esc(v)}" aria-label="${esc(label)}" title="${esc(label)}"
      class="rounded-lg p-2 transition ${tone}">${ic(icon, "w-4 h-4")}</button>`;

  const badge = (s) =>
    `<span class="whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold ${STATUS_COR[s] || "bg-gray-100 text-gray-700"}">${esc(s)}</span>`;

  const empty = (icon, t, p, action = "") => `
    <div class="flex flex-col items-center px-6 py-12 text-center">
      <div class="mb-3 rounded-2xl bg-[#1E2A78]/10 p-4 text-[#1E2A78]">${ic(icon, "w-7 h-7")}</div>
      <p class="font-bold">${t}</p>
      <p class="mt-1 max-w-sm text-sm text-[#6B7280]">${p}</p>
      ${action ? `<div class="mt-4">${action}</div>` : ""}
    </div>`;

  const TONS = {
    navy: "bg-[#1E2A78]/10 text-[#1E2A78]",
    red: "bg-red-50 text-[#C8102E]",
    yellow: "bg-yellow-100 text-yellow-800",
    green: "bg-green-100 text-green-800",
    rose: "bg-rose-100 text-rose-800"
  };

  const stat = (icon, label, valor, dica, rota, tom = "navy") => `
    <a href="#/${rota}" class="${CARD} block p-4 transition hover:-translate-y-0.5 hover:shadow-md">
      <span class="inline-flex rounded-xl p-2 ${TONS[tom]}">${ic(icon, "w-[18px] h-[18px]")}</span>
      <p class="mt-3 text-sm font-semibold">${label}</p>
      <p class="text-3xl font-bold text-[#1E2A78]">${valor}</p>
      <p class="text-xs text-[#6B7280]">${dica}</p>
    </a>`;

  const avatar = (nome, s = 36, foto = "") => `
    <div style="width:${s}px;height:${s}px" class="flex shrink-0 items-center justify-center overflow-hidden rounded-full bg-[#1E2A78] text-xs font-semibold text-white">
      ${foto
        ? `<img src="${esc(foto)}" alt="Foto de ${esc(nome || "responsável")}" class="h-full w-full object-cover">`
        : nome ? esc(nome.split(" ").map((n) => n[0]).slice(0, 2).join("").toUpperCase()) : ic("user", "w-1/2 h-1/2")}
    </div>`;

  const pg = (h) => `<div class="space-y-6 px-4 pb-10 lg:px-8">${h}</div>`;

  const ttl = (icon, t, extra = "") => `
    <div class="flex flex-wrap items-center justify-between gap-2">
      <h2 class="flex items-center gap-2 font-bold text-[#1E2A78]">${ic(icon, "w-[18px] h-[18px]")} ${t}</h2>
      ${extra}
    </div>`;

  const tabela = (cols, rows, vazio) =>
    rows.length
      ? `<div class="adm-scroll overflow-x-auto">
          <table class="adm-tabela w-full min-w-[720px] text-sm">
            <thead><tr class="border-b border-[#E5E7EB] text-left text-xs uppercase tracking-wide text-[#6B7280]">
              ${cols.map((c) => `<th scope="col" class="px-3 py-2.5 font-semibold ${c[2] || ""}">${c[0]}</th>`).join("")}
            </tr></thead>
            <tbody>
              ${rows.map((r) => `<tr class="border-b border-[#F1F2F4] last:border-0">
                ${cols.map((c) => `<td class="px-3 py-3 align-middle ${c[2] || ""}">${c[1](r)}</td>`).join("")}
              </tr>`).join("")}
            </tbody>
          </table>
        </div>`
      : vazio;

  /* ----- campos de formulário (dentro de modais) ----- */

  const lbl = (l, req) => `<span class="mb-1 block text-xs font-semibold">${l}${req ? ' <span class="text-[#C8102E]" aria-hidden="true">*</span>' : ""}</span>`;

  const fld = (l, name, { type = "text", val = "", req = false, ph = "", list = "", attrs = "" } = {}) =>
    `<label class="block">${lbl(l, req)}
      <input name="${name}" type="${type}" value="${esc(val)}" placeholder="${esc(ph)}" ${req ? "required" : ""} ${list ? `list="${list}"` : ""} ${attrs} class="${FLD}">
    </label>`;

  const optsHtml = (opts, val) =>
    opts.map((o) => {
      const [v, t] = Array.isArray(o) ? o : [o, o];
      return `<option value="${esc(v)}" ${String(val) === String(v) ? "selected" : ""}>${esc(t)}</option>`;
    }).join("");

  const sel = (l, name, opts, val = "", { req = false, ph = "Selecione" } = {}) =>
    `<label class="block">${lbl(l, req)}
      <select name="${name}" ${req ? "required" : ""} class="${FLD}">
        <option value="">${ph}</option>${optsHtml(opts, val)}
      </select>
    </label>`;

  /* ----- filtros (fora dos modais; atualizam só a lista) ----- */

  const fBusca = (path, ph) => {
    const [v, k] = path.split(".");
    return `<label class="relative min-w-[200px] flex-1">
      <span class="sr-only">${esc(ph)}</span>
      <span class="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[#6B7280]">${ic("search")}</span>
      <input data-f="${path}" type="search" value="${esc(S.f[v][k])}" placeholder="${esc(ph)}" class="${FLD} pl-9">
    </label>`;
  };

  const fSel = (path, ph, opts) => {
    const [v, k] = path.split(".");
    return `<label class="min-w-[150px]">
      <span class="sr-only">${esc(ph)}</span>
      <select data-f="${path}" class="${FLD}"><option value="">${esc(ph)}</option>${optsHtml(opts, S.f[v][k])}</select>
    </label>`;
  };

  const fData = (path, ph) => {
    const [v, k] = path.split(".");
    return `<label class="min-w-[150px]">
      <span class="sr-only">${esc(ph)}</span>
      <input data-f="${path}" type="date" value="${esc(S.f[v][k])}" title="${esc(ph)}" class="${FLD}">
    </label>`;
  };

  /* ----- modais ----- */

  const modalBox = (titulo, corpo, { w = "max-w-lg" } = {}) => `
    <div class="fixed inset-0 z-50 flex items-end justify-center bg-black/40 sm:items-center sm:p-4" data-a="fecharFundo">
      <div class="${CARD} max-h-[92vh] w-full ${w} overflow-y-auto rounded-b-none sm:rounded-b-2xl" role="dialog" aria-modal="true" aria-label="${esc(titulo)}">
        <div class="flex items-center justify-between border-b border-[#E5E7EB] px-5 py-4">
          <h3 class="font-bold text-[#1E2A78]">${esc(titulo)}</h3>
          <button type="button" data-a="fechar" aria-label="Fechar" class="rounded-lg p-1 text-[#6B7280] hover:bg-gray-100">${ic("x", "w-5 h-5")}</button>
        </div>
        <div class="p-5">${corpo}</div>
      </div>
    </div>`;

  let ultimoFoco = null;

  const abrirModal = (html) => {
    ultimoFoco = document.activeElement;
    $("#modal-root").innerHTML = html;
    icons();
    const alvo = $("#modal-root input:not([type=hidden]), #modal-root select, #modal-root textarea") ||
      $("#modal-root [data-a=fechar]");
    if (alvo) alvo.focus();
  };

  const fecharModal = () => {
    $("#modal-root").innerHTML = "";
    if (ultimoFoco && document.contains(ultimoFoco)) ultimoFoco.focus();
  };

  const confirmar = ({ titulo, corpo, rotulo, acao, v, k = "primary", bloqueado = false }) =>
    modalBox(titulo, `
      ${corpo}
      <div class="mt-5 flex justify-end gap-2">
        ${btn("Voltar", { a: "fechar", k: "ghost" })}
        ${btn(rotulo, { a: acao, v, k, dis: bloqueado })}
      </div>`, { w: "max-w-md" });

  const aviso = (t, tom = "yellow") =>
    `<p class="mt-3 flex gap-2 rounded-xl p-3 text-sm ${TONS[tom]}">${ic("alert-triangle", "mt-0.5 h-4 w-4 shrink-0")}<span>${t}</span></p>`;

  const erroForm = `<p data-erro class="hidden rounded-xl bg-rose-50 px-3 py-2 text-sm text-rose-700" role="alert"></p>`;

  /* ================================================================
     LAYOUT (barra lateral exclusiva do ADM)
     ================================================================ */

  const NAV = [
    ["dashboard", "Dashboard", "layout-dashboard"],
    ["salas", "Salas", "building-2"],
    ["solicitacoes", "Solicitações", "clipboard-list"],
    ["reservas", "Reservas", "calendar-check"],
    ["calendario", "Calendário", "calendar-days"],
    ["usuarios", "Usuários", "users"],
    ["notificacoes", "Notificações", "bell"],
    ["historico", "Histórico", "history"],
    ["configuracoes", "Configurações", "settings"]
  ];

  const navItem = (k, l, i, n) => {
    const ativo = S.view === k;
    return `<a href="#/${k}" ${ativo ? 'aria-current="page"' : ""}
      class="relative flex w-full items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-semibold transition ${ativo ? "bg-white text-[#1E2A78] shadow-sm" : "text-white hover:bg-white/10"}">
      ${ativo ? '<span class="absolute bottom-2 left-0 top-2 w-1 rounded-r bg-[#C8102E]"></span>' : ""}
      ${ic(i, "w-[18px] h-[18px]")}
      <span class="flex-1">${l}</span>
      ${n ? `<span class="rounded-full bg-[#C8102E] px-2 py-0.5 text-[11px] font-bold leading-none text-white" aria-label="${n} pendente(s)">${n}</span>` : ""}
    </a>`;
  };

  const layout = (conteudo) => {
    const pend = S.reservas.filter(PEND).length;
    const naoLidas = S.notificacoes.filter((n) => !n.lida).length;
    const cont = { solicitacoes: pend, notificacoes: naoLidas };
    const titulo = views[S.view].titulo;

    return `
      <div class="min-h-screen">

        ${S.menu ? '<div class="fixed inset-0 z-30 bg-black/40 lg:hidden" data-a="menu" data-v="0"></div>' : ""}

        <aside class="fixed inset-y-0 left-0 z-40 flex w-64 flex-col bg-[#1E2A78] p-4 transition-transform lg:translate-x-0 ${S.menu ? "translate-x-0" : "-translate-x-full"}" aria-label="Menu do administrador">
          <div class="mb-6 px-2">
            <img src="../assets/imagens/senai-logo.png" alt="SENAI" width="180" height="46" class="h-auto w-44 rounded-md">
            <p class="mt-2 flex items-center gap-1.5 text-sm font-semibold text-white">${ic("shield-check", "w-4 h-4")} Administração</p>
          </div>

          <nav class="adm-scroll flex-1 space-y-1 overflow-y-auto">
            ${NAV.map(([k, l, i]) => navItem(k, l, i, cont[k])).join("")}
          </nav>

          <div class="border-t border-white/30 pt-3">
            <button type="button" data-a="pedirSair"
              class="flex w-full items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-white/10">
              ${ic("log-out", "w-[18px] h-[18px]")} Sair
            </button>
          </div>
        </aside>

        <div class="lg:pl-64">

          <header class="flex items-center justify-between px-4 py-4 lg:px-8">
            <div class="flex items-center gap-3">
              <button type="button" class="lg:hidden" data-a="menu" data-v="1" aria-label="Abrir menu">${ic("menu", "w-6 h-6")}</button>
              <h1 class="text-xl font-bold text-[#1E2A78]">${titulo}</h1>
            </div>

            <div class="flex items-center gap-3">
              <a href="#/notificacoes" class="relative rounded-full p-2 text-[#1E2A78] transition hover:bg-[#1E2A78]/10" aria-label="Notificações${naoLidas ? ` (${naoLidas} não lidas)` : ""}">
                ${ic("bell", "w-5 h-5")}
                ${naoLidas ? '<span class="absolute right-1 top-1 h-2.5 w-2.5 rounded-full bg-[#C8102E]"></span>' : ""}
              </a>
              <div class="flex items-center gap-2">
                ${avatar(S.sessao?.nome || "Administrador", 40, S.sessao?.foto)}
                <span class="hidden text-left text-sm sm:block">
                  <b class="block">${esc(autor())}</b>
                  <span class="text-xs text-[#6B7280]">Administrador</span>
                </span>
              </div>
            </div>
          </header>

          <main>${conteudo}</main>
        </div>
      </div>`;
  };

  /* ================================================================
     DETALHE DE RESERVA / SOLICITAÇÃO
     ================================================================ */

  const salaDe = (r) => S.salas.find((s) => String(s.id) === String(r.salaId));

  const profCell = (r) => `
    <div class="flex items-center gap-2">
      ${avatar(r.responsavel, 32, r.fotoProfessor)}
      <div class="min-w-0">
        <p class="truncate font-semibold">${esc(r.responsavel || "Professor")}</p>
        ${r.turma ? `<p class="truncate text-xs text-[#6B7280]">Turma ${esc(r.turma)}</p>` : ""}
      </div>
    </div>`;

  const detalheReserva = (r) => {
    const sala = salaDe(r);
    const linhas = [
      ["Espaço", r.espaco],
      ["Bloco", r.bloco],
      ["Andar", r.piso || sala?.piso],
      ["Data", fmtData(r.data)],
      ["Horário", r.inicio && r.fim ? `${r.inicio} – ${r.fim}` : ""],
      ["Turma", r.turma],
      ["Finalidade", r.finalidade],
      ["Nº de pessoas", r.pessoas],
      ["Solicitada em", r.criadaEm ? fmtDataHora(r.criadaEm) : ""],
      ["Descrição", r.descricao]
    ];

    const acoes = PEND(r)
      ? `${btn("Recusar", { a: "pedirRecusar", v: r.id, i: "x-circle", k: "danger" })}
         ${btn("Aprovar", { a: "pedirAprovar", v: r.id, i: "check-circle-2", k: "navy" })}`
      : APROV(r)
        ? btn("Cancelar reserva", { a: "pedirCancelar", v: r.id, i: "trash-2", k: "primary" })
        : "";

    return modalBox(`Reserva ${r.numero ? "nº " + r.numero : ""}`.trim(), `
      <div class="mb-4 flex items-center justify-between">${badge(r.status)}</div>

      <div class="mb-5 flex items-center gap-4 rounded-xl bg-[#F8F9FA] p-4">
        ${r.fotoProfessor
          ? `<img src="${esc(r.fotoProfessor)}" alt="Foto do responsável" class="h-24 w-24 shrink-0 rounded-full border-2 border-[#C8102E] object-cover">`
          : `<div class="shrink-0">${avatar(r.responsavel, 96)}</div>`}
        <div>
          <p class="text-xs text-[#6B7280]">Responsável</p>
          <p class="font-bold text-[#1E2A78]">${esc(r.responsavel || "Professor")}</p>
          <p class="mt-1 text-xs text-[#6B7280]">${r.fotoProfessor ? "Foto registrada no momento da reserva." : "Nenhuma foto enviada com esta reserva."}</p>
        </div>
      </div>

      <dl class="grid gap-3 sm:grid-cols-2">
        ${linhas.map(([k, v]) => `
          <div class="${k === "Descrição" ? "sm:col-span-2" : ""}">
            <dt class="text-xs text-[#6B7280]">${k}</dt>
            <dd class="text-sm font-semibold text-[#1E2A78]">${esc(v) || "--"}</dd>
          </div>`).join("")}
      </dl>

      ${r.motivoRecusa ? aviso(`<b>Motivo da recusa:</b> ${esc(r.motivoRecusa)}`, "rose") : ""}
      ${r.motivoCancelamento ? aviso(`<b>Motivo do cancelamento:</b> ${esc(r.motivoCancelamento)}`, "rose") : ""}

      ${acoes ? `<div class="mt-5 flex flex-wrap justify-end gap-2">${acoes}</div>` : ""}
    `, { w: "max-w-xl" });
  };

  /* ================================================================
     TELAS
     ================================================================ */

  const views = {};

  /* ---------------- DASHBOARD ---------------- */

  views.dashboard = {
    titulo: "Dashboard",
    html: () => {
      const pend = S.reservas.filter(PEND).length;
      const aprov = S.reservas.filter(APROV).length;
      const recus = S.reservas.filter((r) => r.status === "Recusada").length;

      const recentes = [...S.reservas]
        .sort((a, b) => String(b.criadaEm || "").localeCompare(String(a.criadaEm || "")))
        .slice(0, 5);

      return pg(`
        <div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          ${stat("building-2", "Salas cadastradas", S.salas.length, "total de salas e espaços", "salas", "navy")}
          ${stat("clock", "Reservas pendentes", pend, "aguardando análise", "solicitacoes", "yellow")}
          ${stat("check-circle-2", "Reservas aprovadas", aprov, "reservas confirmadas", "reservas", "green")}
          ${stat("x-circle", "Reservas recusadas", recus, "solicitações recusadas", "solicitacoes", "rose")}
        </div>

        <div class="grid gap-6 xl:grid-cols-[1fr_300px]">

          <div class="${CARD} p-5">
            ${ttl("clipboard-list", "Solicitações recentes", `<a href="#/solicitacoes" class="text-sm font-semibold text-[#C8102E] hover:underline">Ver todas</a>`)}
            <div class="mt-4">
              ${tabela([
                ["Professor", profCell],
                ["Espaço", (r) => esc(r.espaco)],
                ["Data e horário", (r) => `${esc(fmtData(r.data))}<br><span class="text-xs text-[#6B7280]">${esc(r.inicio)}–${esc(r.fim)}</span>`],
                ["Status", (r) => badge(r.status)],
                ["", (r) => iconBtn("eye", "Ver detalhes", "ver", r.id), "text-right"]
              ], recentes, empty("clipboard-list", "Nenhuma solicitação ainda", "As solicitações feitas pelos professores aparecerão aqui."))}
            </div>
          </div>

          <div class="${CARD} p-5">
            ${ttl("building-2", "Salas por bloco")}
            <ul class="mt-4 space-y-3">
              ${BLOCOS.map((b) => `
                <li class="flex items-center justify-between rounded-xl bg-[#F8F9FA] px-4 py-3">
                  <span class="font-semibold">Bloco ${b}</span>
                  <span class="text-xl font-bold text-[#1E2A78]">${S.salas.filter((s) => s.bloco === b).length}</span>
                </li>`).join("")}
            </ul>
            ${S.salas.length ? "" : `<p class="mt-3 text-xs text-[#6B7280]">Cadastre as salas em <a class="font-semibold text-[#C8102E] hover:underline" href="#/salas">Salas</a>.</p>`}
          </div>

        </div>`);
    }
  };

  /* ---------------- SALAS ---------------- */

  views.salas = {
    titulo: "Gerenciar salas",
    html: () => pg(`
      <div class="${CARD} p-5">
        <div class="flex flex-wrap items-center gap-3">
          ${fBusca("salas.q", "Buscar por nome, tipo ou descrição")}
          ${fSel("salas.bloco", "Todos os blocos", BLOCOS.map((b) => [b, "Bloco " + b]))}
          ${fSel("salas.tipo", "Todos os tipos", TIPOS)}
          ${btn("Nova sala", { a: "novaSala", i: "plus" })}
        </div>
        <div id="res" class="mt-4">${views.salas.list()}</div>
      </div>`),

    list: () => {
      const f = S.f.salas, q = f.q.trim().toLowerCase();
      const rows = S.salas
        .filter((s) =>
          (!q || [s.nome, s.tipo, s.descricao, s.piso].some((x) => String(x ?? "").toLowerCase().includes(q))) &&
          (!f.bloco || s.bloco === f.bloco) &&
          (!f.tipo || s.tipo === f.tipo))
        .sort((a, b) => String(a.bloco).localeCompare(b.bloco) || String(a.nome).localeCompare(b.nome));

      const vazio = S.salas.length
        ? empty("search", "Nenhuma sala encontrada", "Ajuste a busca ou os filtros.")
        : empty("building-2", "Nenhuma sala cadastrada", "Cadastre a primeira sala. Ela ficará disponível para os professores na seleção de espaços.",
            btn("Cadastrar sala", { a: "novaSala", i: "plus" }));

      return tabela([
        ["Espaço", (s) => `<div class="flex items-center gap-3">${s.imagem ? `<img src="${esc(s.imagem)}" alt="Foto de ${esc(s.nome)}" class="h-12 w-16 rounded-lg border border-[#E5E7EB] object-cover">` : `<div class="flex h-12 w-16 items-center justify-center rounded-lg bg-[#F1F2F4] text-[#9CA3AF]"><i data-lucide="image" class="h-5 w-5"></i></div>`}<div><p class="font-semibold text-[#1E2A78]">${esc(s.nome)}</p><p class="text-xs text-[#6B7280]">${esc(s.tipo)}</p></div></div>`],
        ["Bloco", (s) => esc(s.bloco)],
        ["Andar", (s) => esc(s.piso)],
        ["Capacidade", (s) => `${esc(s.capacidade)} pessoas`],
        ["Equipamentos", (s) => {
          const e = s.equipamentos || [];
          return e.length
            ? e.slice(0, 3).map((x) => `<span class="mr-1 inline-block rounded-full bg-[#F1F2F4] px-2 py-0.5 text-xs">${esc(x)}</span>`).join("") +
              (e.length > 3 ? `<span class="text-xs text-[#6B7280]">+${e.length - 3}</span>` : "")
            : '<span class="text-xs text-[#9CA3AF]">--</span>';
        }],
        ["Ações", (s) => `<div class="flex justify-end gap-1">
            ${iconBtn("pencil", "Editar sala", "editarSala", s.id)}
            ${iconBtn("trash-2", "Excluir sala", "pedirExcluirSala", s.id, "text-[#C8102E] hover:bg-red-50")}
          </div>`, "text-right"]
      ], rows, vazio);
    }
  };

  const formSala = (s = null) => modalBox(s ? "Editar sala" : "Nova sala", `
    <form data-form="sala" data-id="${esc(s?.id ?? "")}" class="space-y-4" novalidate>
      ${fld("Nome da sala", "nome", { val: s?.nome, req: true, ph: "Ex.: Laboratório de Informática 1" })}
      <div class="grid gap-4 sm:grid-cols-2">
        ${sel("Bloco", "bloco", BLOCOS.map((b) => [b, "Bloco " + b]), s?.bloco, { req: true })}
        ${fld("Andar", "piso", { val: s?.piso, req: true, ph: "Ex.: Térreo, 1º andar", list: "lista-andares" })}
        <datalist id="lista-andares"><option value="Térreo"><option value="1º andar"><option value="2º andar"><option value="3º andar"></datalist>
        ${fld("Capacidade (pessoas)", "capacidade", { type: "number", val: s?.capacidade, req: true, attrs: 'min="1" step="1"' })}
        ${sel("Tipo de espaço", "tipo", TIPOS, s?.tipo, { req: true })}
      </div>
      <fieldset>
        <legend class="mb-1 text-xs font-semibold">Equipamentos</legend>
        <div class="flex flex-wrap gap-2">
          ${EQUIP.map((e) => `
            <label class="flex cursor-pointer items-center gap-2 rounded-xl border border-[#E5E7EB] px-3 py-2 text-sm has-[:checked]:border-[#1E2A78] has-[:checked]:bg-[#1E2A78]/5">
              <input type="checkbox" name="equip" value="${esc(e)}" ${(s?.equipamentos || []).includes(e) ? "checked" : ""} class="accent-[#1E2A78]"> ${esc(e)}
            </label>`).join("")}
        </div>
      </fieldset>
      <label class="block">${lbl("Foto da sala (opcional)")}
        <input name="imagemArquivo" type="file" accept="image/*" class="${FLD} file:mr-3 file:rounded-lg file:border-0 file:bg-[#1E2A78]/10 file:px-3 file:py-2 file:text-sm file:font-semibold file:text-[#1E2A78]">
        <span class="mt-1 block text-xs text-[#6B7280]">Escolha uma imagem JPG, PNG ou WEBP. A foto fica salva neste navegador no modo de demonstração.</span>
        <div data-preview-foto class="${s?.imagem ? "" : "hidden"} mt-3">${s?.imagem ? `<img src="${esc(s.imagem)}" alt="Prévia da foto da sala" class="h-36 w-full rounded-xl border border-[#E5E7EB] object-cover">` : ""}</div>
      </label>
      <label class="block">${lbl("Descrição")}
        <textarea name="descricao" rows="3" placeholder="Informações úteis sobre o espaço" class="${FLD}">${esc(s?.descricao)}</textarea>
      </label>
      ${erroForm}
      <div class="flex justify-end gap-2">
        ${btn("Cancelar", { a: "fechar", k: "ghost" })}
        ${btn(s ? "Salvar alterações" : "Cadastrar sala", { type: "submit", k: "navy", i: "save" })}
      </div>
    </form>`);

  /* ---------------- SOLICITAÇÕES ---------------- */

  const filtrarReservas = (lista, f) => {
    const q = f.q.trim().toLowerCase();
    return lista.filter((r) =>
      (!q || [r.responsavel, r.espaco, r.turma, r.numero].some((x) => String(x ?? "").toLowerCase().includes(q))) &&
      (!f.status || r.status === f.status) &&
      (!f.bloco || r.bloco === f.bloco) &&
      (!f.data || r.data === f.data));
  };

  views.solicitacoes = {
    titulo: "Solicitações de reserva",
    html: () => pg(`
      <div class="${CARD} p-5">
        <div class="flex flex-wrap items-center gap-3">
          ${fBusca("solicitacoes.q", "Buscar por professor, sala ou turma")}
          ${fSel("solicitacoes.status", "Todos os status", STATUS_RESERVA)}
          ${fData("solicitacoes.data", "Data da reserva")}
        </div>
        <div id="res" class="mt-4">${views.solicitacoes.list()}</div>
      </div>`),

    list: () => {
      const ordem = { "Em análise": 0 };
      const rows = filtrarReservas(S.reservas, S.f.solicitacoes)
        .sort((a, b) => (ordem[a.status] ?? 1) - (ordem[b.status] ?? 1) || String(a.data).localeCompare(b.data));

      const vazio = S.reservas.length
        ? empty("search", "Nenhuma solicitação encontrada", "Ajuste a busca ou os filtros.")
        : empty("clipboard-list", "Nenhuma solicitação ainda", "Quando um professor solicitar uma reserva, ela aparecerá aqui para aprovação.");

      return tabela([
        ["Nº", (r) => esc(r.numero || "--")],
        ["Professor", profCell],
        ["Espaço", (r) => `${esc(r.espaco)}<br><span class="text-xs text-[#6B7280]">Bloco ${esc(r.bloco)}</span>`],
        ["Data e horário", (r) => `${esc(fmtData(r.data))}<br><span class="text-xs text-[#6B7280]">${esc(r.inicio)}–${esc(r.fim)}</span>`],
        ["Status", (r) => badge(r.status)],
        ["Ações", (r) => `<div class="flex justify-end gap-1">
            ${iconBtn("eye", "Ver detalhes", "ver", r.id)}
            ${PEND(r) ? iconBtn("check-circle-2", "Aprovar", "pedirAprovar", r.id, "text-green-700 hover:bg-green-50") +
              iconBtn("x-circle", "Recusar", "pedirRecusar", r.id, "text-[#C8102E] hover:bg-red-50") : ""}
          </div>`, "text-right"]
      ], rows, vazio);
    }
  };

  /* ---------------- RESERVAS CONFIRMADAS ---------------- */

  views.reservas = {
    titulo: "Reservas confirmadas",
    html: () => pg(`
      <div class="${CARD} p-5">
        <div class="flex flex-wrap items-center gap-3">
          ${fBusca("reservas.q", "Buscar por responsável, sala ou turma")}
          ${fSel("reservas.bloco", "Todos os blocos", BLOCOS.map((b) => [b, "Bloco " + b]))}
          ${fData("reservas.data", "Data da reserva")}
        </div>
        <div id="res" class="mt-4">${views.reservas.list()}</div>
      </div>`),

    list: () => {
      const todas = S.reservas.filter(APROV);
      const rows = filtrarReservas(todas, { ...S.f.reservas, status: "" })
        .sort((a, b) => String(a.data).localeCompare(b.data) || String(a.inicio).localeCompare(b.inicio));

      const vazio = todas.length
        ? empty("search", "Nenhuma reserva encontrada", "Ajuste a busca ou os filtros.")
        : empty("calendar-check", "Nenhuma reserva confirmada", "As solicitações aprovadas aparecerão aqui.");

      return tabela([
        ["Nº", (r) => esc(r.numero || "--")],
        ["Responsável", profCell],
        ["Espaço", (r) => `${esc(r.espaco)}<br><span class="text-xs text-[#6B7280]">Bloco ${esc(r.bloco)}</span>`],
        ["Data e horário", (r) => `${esc(fmtData(r.data))}<br><span class="text-xs text-[#6B7280]">${esc(r.inicio)}–${esc(r.fim)}</span>`],
        ["Ações", (r) => `<div class="flex justify-end gap-1">
            ${iconBtn("eye", "Ver detalhes", "ver", r.id)}
            ${iconBtn("trash-2", "Cancelar reserva", "pedirCancelar", r.id, "text-[#C8102E] hover:bg-red-50")}
          </div>`, "text-right"]
      ], rows, vazio);
    }
  };

  /* ---------------- CALENDÁRIO ---------------- */

  const horasFunc = () => {
    const a = S.config.abertura ? min(S.config.abertura) : 7 * 60;
    const f = S.config.fechamento ? min(S.config.fechamento) : 22 * 60;
    const ini = Math.floor(a / 60), fim = Math.max(ini + 1, Math.ceil(f / 60));
    return Array.from({ length: fim - ini }, (_, i) => ini + i);
  };

  const diaFechado = (d) => S.config.dias.length > 0 && !S.config.dias.includes(d.getDay());

  const reservasDoDia = (dia) =>
    S.reservas.filter((r) =>
      r.data === dia && (APROV(r) || PEND(r)) &&
      (!S.f.cal.sala || String(r.salaId) === S.f.cal.sala));

  const noHorario = (lista, h) =>
    lista.filter((r) => min(r.inicio) < (h + 1) * 60 && min(r.fim) > h * 60);

  const chip = (r, curto = false) => `
    <button type="button" data-a="ver" data-v="${esc(r.id)}"
      class="block w-full truncate rounded-lg px-2 py-1 text-left text-xs font-semibold ${APROV(r) ? "bg-rose-100 text-rose-800" : "bg-yellow-100 text-yellow-800"}"
      title="${esc(r.espaco)} · ${esc(r.inicio)}–${esc(r.fim)} · ${esc(r.responsavel)} (${APROV(r) ? "Ocupado" : "Pendente"})">
      ${esc(r.espaco)}${curto ? "" : ` · ${esc(r.inicio)}–${esc(r.fim)} · ${esc(r.responsavel || "")}`}
    </button>`;

  const livre = `<span class="text-xs font-semibold text-green-700">Livre</span>`;

  const calTitulo = () => {
    const { modo, ref } = S.f.cal, d = parseISO(ref);
    if (modo === "mes") return `${MESES[d.getMonth()]} de ${d.getFullYear()}`;
    if (modo === "dia") return d.toLocaleDateString("pt-BR", { dateStyle: "full" });
    const ini = parseISO(addDias(ref, -d.getDay())), fim = parseISO(addDias(ref, 6 - d.getDay()));
    const c = (x) => x.toLocaleDateString("pt-BR", { day: "2-digit", month: "short" });
    return `${c(ini)} – ${c(fim)} de ${fim.getFullYear()}`;
  };

  const calMes = () => {
    const ref = parseISO(S.f.cal.ref);
    const y = ref.getFullYear(), m = ref.getMonth();
    const off = new Date(y, m, 1).getDay();
    const dim = new Date(y, m + 1, 0).getDate();
    const total = Math.ceil((off + dim) / 7) * 7;
    const hoje = hojeISO();

    const cel = Array.from({ length: total }, (_, i) => {
      const n = i - off + 1;
      if (n < 1 || n > dim) return '<div class="min-h-[84px] bg-[#F8F9FA]"></div>';
      const dia = iso(new Date(y, m, n));
      const lista = reservasDoDia(dia);
      const oc = lista.filter(APROV).length, pe = lista.filter(PEND).length;
      const fechado = diaFechado(new Date(y, m, n));
      return `
        <button type="button" data-a="calDia" data-v="${dia}" aria-label="Dia ${n}: ${oc} ocupada(s), ${pe} pendente(s)"
          class="min-h-[84px] bg-white p-1.5 text-left transition hover:bg-[#1E2A78]/5 ${fechado ? "opacity-60" : ""}">
          <span class="inline-flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold ${dia === hoje ? "bg-[#C8102E] text-white" : ""}">${n}</span>
          ${oc ? `<span class="mt-1 block rounded bg-rose-100 px-1.5 py-0.5 text-[11px] font-semibold text-rose-800">${oc} ocupada${oc > 1 ? "s" : ""}</span>` : ""}
          ${pe ? `<span class="mt-1 block rounded bg-yellow-100 px-1.5 py-0.5 text-[11px] font-semibold text-yellow-800">${pe} pendente${pe > 1 ? "s" : ""}</span>` : ""}
          ${fechado ? '<span class="mt-1 block text-[11px] text-[#6B7280]">Fechado</span>' : ""}
        </button>`;
    }).join("");

    return `<div class="adm-scroll overflow-x-auto">
      <div class="min-w-[640px]">
        <div class="grid grid-cols-7 gap-px text-center text-xs font-semibold text-[#6B7280]">${DIAS.map((d) => `<div class="py-2">${d}</div>`).join("")}</div>
        <div class="grid grid-cols-7 gap-px overflow-hidden rounded-xl border border-[#E5E7EB] bg-[#E5E7EB]">${cel}</div>
      </div></div>`;
  };

  const calSemana = () => {
    const ref = S.f.cal.ref, d = parseISO(ref);
    const dias = Array.from({ length: 7 }, (_, i) => addDias(ref, i - d.getDay()));
    const doDia = Object.fromEntries(dias.map((x) => [x, reservasDoDia(x)]));
    const hoje = hojeISO();

    return `<div class="adm-scroll overflow-x-auto">
      <table class="w-full min-w-[760px] table-fixed border-collapse text-sm">
        <thead><tr>
          <th class="w-16 p-2"></th>
          ${dias.map((x) => {
            const dd = parseISO(x);
            return `<th class="p-2"><button type="button" data-a="calDia" data-v="${x}"
              class="w-full rounded-lg py-1 text-xs font-semibold hover:bg-[#1E2A78]/5 ${x === hoje ? "text-[#C8102E]" : "text-[#6B7280]"}">${DIAS[dd.getDay()]}<br><span class="text-base font-bold ${x === hoje ? "text-[#C8102E]" : "text-[#1E2A78]"}">${dd.getDate()}</span></button></th>`;
          }).join("")}
        </tr></thead>
        <tbody>
          ${horasFunc().map((h) => `<tr class="border-t border-[#E5E7EB]">
            <th scope="row" class="p-2 text-right text-xs font-semibold text-[#6B7280]">${pad(h)}:00</th>
            ${dias.map((x) => {
              const l = noHorario(doDia[x], h);
              const fechado = diaFechado(parseISO(x));
              return `<td class="space-y-1 border-l border-[#E5E7EB] p-1 align-top ${fechado ? "bg-[#F8F9FA]" : ""}">
                ${fechado ? '<span class="text-xs text-[#9CA3AF]">Fechado</span>'
                  : l.length ? l.slice(0, 2).map((r) => chip(r, true)).join("") + (l.length > 2 ? `<span class="text-[11px] text-[#6B7280]">+${l.length - 2}</span>` : "")
                  : livre}</td>`;
            }).join("")}
          </tr>`).join("")}
        </tbody>
      </table></div>`;
  };

  const calDia = () => {
    const ref = S.f.cal.ref, lista = reservasDoDia(ref), fechado = diaFechado(parseISO(ref));
    return `${fechado ? aviso("O dia selecionado está fora dos dias de funcionamento configurados.", "yellow") : ""}
      <ul class="mt-3 divide-y divide-[#E5E7EB] rounded-xl border border-[#E5E7EB]">
        ${horasFunc().map((h) => {
          const l = noHorario(lista, h);
          return `<li class="flex gap-3 p-2 ${l.length ? "" : "bg-green-50/50"}">
            <span class="w-14 shrink-0 pt-1 text-right text-xs font-semibold text-[#6B7280]">${pad(h)}:00</span>
            <div class="min-w-0 flex-1 space-y-1">${l.length ? l.map((r) => chip(r)).join("") : (fechado ? '<span class="text-xs text-[#9CA3AF]">Fechado</span>' : livre)}</div>
          </li>`;
        }).join("")}
      </ul>`;
  };

  views.calendario = {
    titulo: "Calendário de reservas",
    html: () => {
      const c = S.f.cal;
      const modos = [["dia", "Dia"], ["semana", "Semana"], ["mes", "Mês"]];
      return pg(`
        <div class="${CARD} p-5">
          <div class="flex flex-wrap items-center gap-3">
            <div class="inline-flex rounded-xl border border-[#E5E7EB] p-1" role="group" aria-label="Modo de visualização">
              ${modos.map(([v, t]) => `<button type="button" data-a="calModo" data-v="${v}" aria-pressed="${c.modo === v}"
                class="rounded-lg px-3 py-1.5 text-sm font-semibold transition ${c.modo === v ? "bg-[#1E2A78] text-white" : "text-[#6B7280] hover:bg-gray-100"}">${t}</button>`).join("")}
            </div>
            <div class="flex items-center gap-1">
              ${iconBtn("chevron-left", "Anterior", "calNav", "-1")}
              ${btn("Hoje", { a: "calHoje", k: "outline", c: "!px-3 !py-1.5" })}
              ${iconBtn("chevron-right", "Próximo", "calNav", "1")}
            </div>
            <h2 class="flex-1 text-base font-bold capitalize text-[#1E2A78]" aria-live="polite">${esc(calTitulo())}</h2>
            <label class="min-w-[200px]">
              <span class="sr-only">Filtrar por sala</span>
              <select data-f="cal.sala" ${S.salas.length ? "" : "disabled"} class="${FLD}">
                <option value="">${S.salas.length ? "Todas as salas" : "Nenhuma sala cadastrada"}</option>
                ${optsHtml(S.salas.map((s) => [s.id, `${s.nome} · Bloco ${s.bloco}`]), c.sala)}
              </select>
            </label>
          </div>

          <div class="mt-3 flex flex-wrap gap-4 text-xs text-[#6B7280]">
            <span class="flex items-center gap-1.5"><span class="h-3 w-3 rounded bg-rose-200"></span> Ocupado (aprovada)</span>
            <span class="flex items-center gap-1.5"><span class="h-3 w-3 rounded bg-yellow-200"></span> Pendente (em análise)</span>
            <span class="flex items-center gap-1.5"><span class="h-3 w-3 rounded bg-green-200"></span> Livre</span>
            ${S.config.abertura ? "" : '<span>Horário exibido: 07:00–22:00 (configure em Configurações)</span>'}
          </div>

          <div id="res" class="mt-4">${views.calendario.list()}</div>
        </div>`);
    },
    list: () => ({ mes: calMes, semana: calSemana, dia: calDia })[S.f.cal.modo]()
  };

  /* ---------------- USUÁRIOS ---------------- */

  const ativo = (u) => u.ativo !== false;

  views.usuarios = {
    titulo: "Usuários",
    html: () => pg(`
      <div class="${CARD} p-5">
        <div class="flex flex-wrap items-center gap-3">
          ${fBusca("usuarios.q", "Buscar por nome, e-mail, matrícula ou CPF")}
          ${fSel("usuarios.status", "Todos os status", [["ativo", "Ativos"], ["inativo", "Inativos"]])}
        </div>
        <div id="res" class="mt-4">${views.usuarios.list()}</div>
      </div>`),

    list: () => {
      const f = S.f.usuarios, q = f.q.trim().toLowerCase();
      const rows = S.usuarios
        .filter((u) =>
          (!q || [u.nome, u.email, u.matricula, u.cpf].some((x) => String(x ?? "").toLowerCase().includes(q))) &&
          (!f.status || (f.status === "ativo") === ativo(u)))
        .sort((a, b) => String(a.nome).localeCompare(b.nome));

      const vazio = S.usuarios.length
        ? empty("search", "Nenhum usuário encontrado", "Ajuste a busca ou os filtros.")
        : empty("users", "Nenhum usuário cadastrado", "Os professores aparecerão aqui depois de criarem a conta.");

      return tabela([
        ["Usuário", (u) => `<div class="flex items-center gap-2">${avatar(u.nome, 36, u.foto)}<div class="min-w-0"><p class="truncate font-semibold">${esc(u.nome)}</p><p class="truncate text-xs text-[#6B7280]">${esc(u.cargo)}</p></div></div>`],
        ["E-mail", (u) => esc(u.email)],
        ["Matrícula", (u) => esc(u.matricula || "--")],
        ["Status", (u) => badge(ativo(u) ? "Ativo" : "Inativo")],
        ["Ações", (u) => `<div class="flex justify-end gap-1">
            ${iconBtn("eye", "Ver dados", "verUsuario", u.id)}
            ${iconBtn("pencil", "Editar", "editarUsuario", u.id)}
            ${ativo(u)
              ? iconBtn("user-x", "Desativar conta", "pedirToggleUsuario", u.id, "text-[#C8102E] hover:bg-red-50")
              : iconBtn("user-check", "Ativar conta", "pedirToggleUsuario", u.id, "text-green-700 hover:bg-green-50")}
          </div>`, "text-right"]
      ], rows, vazio);
    }
  };

  const CAMPOS_USR = [
    ["nome", "Nome completo"], ["cpf", "CPF"], ["email", "E-mail institucional"],
    ["nascimento", "Data de nascimento"], ["telefone", "Telefone"], ["matricula", "Matrícula"], ["cargo", "Cargo"]
  ];

  const usuarioVer = (u) => modalBox("Dados do usuário", `
    <div class="mb-4 flex items-center gap-4">
      ${avatar(u.nome, 72, u.foto)}
      <div><p class="font-bold text-[#1E2A78]">${esc(u.nome)}</p>${badge(ativo(u) ? "Ativo" : "Inativo")}</div>
    </div>
    <dl class="grid gap-3 sm:grid-cols-2">
      ${CAMPOS_USR.map(([k, l]) => `<div><dt class="text-xs text-[#6B7280]">${l}</dt>
        <dd class="text-sm font-semibold text-[#1E2A78]">${esc(k === "nascimento" ? fmtData(u[k]) : u[k]) || "--"}</dd></div>`).join("")}
    </dl>
    <div class="mt-5 flex justify-end gap-2">${btn("Editar", { a: "editarUsuario", v: u.id, i: "pencil", k: "navy" })}</div>`);

  const usuarioForm = (u) => modalBox("Editar usuário", `
    <form data-form="usuario" data-id="${esc(u.id)}" class="space-y-4" novalidate>
      <div class="grid gap-4 sm:grid-cols-2">
        ${fld("Nome completo", "nome", { val: u.nome, req: true })}
        ${fld("E-mail institucional", "email", { type: "email", val: u.email, req: true })}
        ${fld("CPF", "cpf", { val: u.cpf })}
        ${fld("Data de nascimento", "nascimento", { type: "date", val: u.nascimento })}
        ${fld("Telefone", "telefone", { type: "tel", val: u.telefone })}
        ${fld("Matrícula", "matricula", { val: u.matricula })}
      </div>
      ${fld("Cargo", "cargo", { val: u.cargo })}
      ${erroForm}
      <div class="flex justify-end gap-2">
        ${btn("Cancelar", { a: "fechar", k: "ghost" })}
        ${btn("Salvar alterações", { type: "submit", k: "navy", i: "save" })}
      </div>
    </form>`);

  /* ---------------- NOTIFICAÇÕES ---------------- */

  views.notificacoes = {
    titulo: "Notificações",
    html: () => {
      const pend = S.reservas.filter(PEND).length;
      const naoLidas = S.notificacoes.filter((n) => !n.lida).length;
      const aba = S.f.notificacoes.aba;
      const tab = (v, t) => `<button type="button" data-a="notAba" data-v="${v}" aria-pressed="${aba === v}"
        class="rounded-lg px-3 py-1.5 text-sm font-semibold transition ${aba === v ? "bg-[#1E2A78] text-white" : "text-[#6B7280] hover:bg-gray-100"}">${t}</button>`;

      return pg(`
        <div class="grid gap-4 sm:grid-cols-2">
          ${stat("clock", "Solicitações pendentes", pend, "aguardando análise", "solicitacoes", "yellow")}
          ${stat("bell", "Notificações não lidas", naoLidas, "novidades no sistema", "notificacoes", "red")}
        </div>
        <div class="${CARD} p-5">
          <div class="flex flex-wrap items-center justify-between gap-3">
            <div class="inline-flex rounded-xl border border-[#E5E7EB] p-1">${tab("todas", "Todas")}${tab("naolidas", "Não lidas")}</div>
            ${btn("Marcar todas como lidas", { a: "lerTodas", i: "check-check", k: "outline", dis: !naoLidas })}
          </div>
          <div id="res" class="mt-4">${views.notificacoes.list()}</div>
        </div>`);
    },

    list: () => {
      const lista = S.notificacoes
        .filter((n) => S.f.notificacoes.aba === "todas" || !n.lida)
        .sort((a, b) => String(b.criadaEm).localeCompare(String(a.criadaEm)));

      if (!lista.length)
        return empty("bell", S.notificacoes.length ? "Nenhuma notificação não lida" : "Nenhuma notificação",
          "Novas solicitações e alterações de reservas aparecerão aqui.");

      return `<ul class="space-y-2">${lista.map((n) => `
        <li class="flex gap-3 rounded-xl border p-3 ${n.lida ? "border-[#E5E7EB] bg-white" : "border-red-200 bg-red-50"}">
          <span class="mt-0.5 text-[#C8102E]">${ic(n.tipo === "alteracao" ? "refresh-cw" : "inbox", "w-[18px] h-[18px]")}</span>
          <div class="min-w-0 flex-1">
            <p class="text-sm font-semibold">${esc(n.titulo)}</p>
            <p class="text-sm text-[#6B7280]">${esc(n.mensagem)}</p>
            <p class="mt-1 text-xs text-[#6B7280]">${esc(fmtDataHora(n.criadaEm))}</p>
          </div>
          <div class="flex shrink-0 flex-col items-end gap-1 sm:flex-row">
            ${n.reservaId !== undefined && S.reservas.some((r) => String(r.id) === String(n.reservaId))
              ? btn("Ver reserva", { a: "notVer", v: n.id, k: "outline", c: "!px-3 !py-1.5 text-xs" }) : ""}
            ${n.lida ? "" : btn("Marcar como lida", { a: "lerNot", v: n.id, k: "ghost", c: "!px-3 !py-1.5 text-xs" })}
          </div>
        </li>`).join("")}</ul>`;
    }
  };

  /* ---------------- HISTÓRICO ---------------- */

  const HIST_ICO = { "Aprovação": ["check-circle-2", "bg-green-100 text-green-800"], "Recusa": ["x-circle", "bg-rose-100 text-rose-800"], "Cancelamento": ["trash-2", "bg-rose-100 text-rose-800"], "Alteração": ["pencil", "bg-[#1E2A78]/10 text-[#1E2A78]"] };

  views.historico = {
    titulo: "Histórico de ações",
    html: () => pg(`
      <div class="${CARD} p-5">
        <div class="flex flex-wrap items-center gap-3">
          ${fBusca("historico.q", "Buscar no histórico")}
          ${fSel("historico.tipo", "Todas as ações", TIPOS_HIST)}
        </div>
        <div id="res" class="mt-4">${views.historico.list()}</div>
      </div>`),

    list: () => {
      const f = S.f.historico, q = f.q.trim().toLowerCase();
      const lista = S.historico.filter((h) =>
        (!q || [h.descricao, h.autor, h.tipo].some((x) => String(x ?? "").toLowerCase().includes(q))) && (!f.tipo || h.tipo === f.tipo));

      if (!lista.length)
        return empty("history", S.historico.length ? "Nada encontrado" : "Nenhuma ação registrada",
          S.historico.length ? "Ajuste a busca ou o filtro." : "Aprovações, recusas, cancelamentos e alterações aparecerão aqui.");

      return `<ol class="space-y-3">${lista.map((h) => {
        const [i, cor] = HIST_ICO[h.tipo] || HIST_ICO["Alteração"];
        return `<li class="flex gap-3 rounded-xl border border-[#E5E7EB] p-3">
          <span class="flex h-9 w-9 shrink-0 items-center justify-center rounded-full ${cor}">${ic(i, "w-4 h-4")}</span>
          <div class="min-w-0 flex-1">
            <p class="text-sm font-semibold">${esc(h.tipo)}</p>
            <p class="text-sm text-[#6B7280]">${esc(h.descricao)}</p>
            <p class="mt-1 text-xs text-[#6B7280]">${esc(fmtDataHora(h.quando))} · ${esc(h.autor)}</p>
          </div></li>`;
      }).join("")}</ol>`;
    }
  };

  /* ---------------- CONFIGURAÇÕES ---------------- */

  views.configuracoes = {
    titulo: "Configurações",
    html: () => {
      const c = S.config;
      return pg(`
        <form data-form="config" class="${CARD} max-w-3xl space-y-6 p-5" novalidate>
          ${ttl("settings", "Regras de reserva")}
          <p class="text-sm text-[#6B7280]">Defina como as reservas devem funcionar. As regras são aplicadas pelo Back-End; aqui elas também alimentam o calendário.</p>

          <fieldset>
            <legend class="mb-2 text-xs font-semibold">Dias de funcionamento</legend>
            <div class="flex flex-wrap gap-2">
              ${DIAS.map((d, i) => `<label class="flex cursor-pointer items-center gap-2 rounded-xl border border-[#E5E7EB] px-3 py-2 text-sm has-[:checked]:border-[#1E2A78] has-[:checked]:bg-[#1E2A78]/5">
                <input type="checkbox" name="dias" value="${i}" ${c.dias.includes(i) ? "checked" : ""} class="accent-[#1E2A78]"> ${d}</label>`).join("")}
            </div>
          </fieldset>

          <div class="grid gap-4 sm:grid-cols-2">
            ${fld("Abertura", "abertura", { type: "time", val: c.abertura })}
            ${fld("Fechamento", "fechamento", { type: "time", val: c.fechamento })}
            ${fld("Duração máxima da reserva (horas)", "duracaoMaxHoras", { type: "number", val: c.duracaoMaxHoras, attrs: 'min="0.5" step="0.5"' })}
            ${fld("Antecedência mínima (horas)", "antecedenciaMinHoras", { type: "number", val: c.antecedenciaMinHoras, attrs: 'min="0" step="1"' })}
            ${fld("Antecedência máxima (dias)", "antecedenciaMaxDias", { type: "number", val: c.antecedenciaMaxDias, attrs: 'min="1" step="1"' })}
          </div>

          ${erroForm}
          <div class="flex justify-end">${btn("Salvar configurações", { type: "submit", k: "navy", i: "save" })}</div>
        </form>`);
    }
  };

  /* ================================================================
     RENDER
     ================================================================ */

  function render() {
    if (!views[S.view]) S.view = "dashboard";
    $("#app").innerHTML = layout(views[S.view].html());
    document.title = `SENAI · ${views[S.view].titulo}`;
    icons();
  }

  function refreshList() {
    const v = views[S.view], el = $("#res");
    if (v && v.list && el) { el.innerHTML = v.list(); icons(); }
  }

  const rota = () => {
    const k = (location.hash.match(/^#\/(\w+)/) || [])[1];
    S.view = views[k] ? k : "dashboard";
    S.menu = false;
    render();
    window.scrollTo(0, 0);
  };

  /* ================================================================
     AÇÕES
     ================================================================ */

  const reservaPorId = (id) => S.reservas.find((r) => String(r.id) === String(id));
  const salaPorId = (id) => S.salas.find((s) => String(s.id) === String(id));
  const usuarioPorId = (id) => S.usuarios.find((u) => String(u.id) === String(id));
  const resumo = (r) => `${r.responsavel || "Professor"} · ${r.espaco} · ${fmtData(r.data)} ${r.inicio}–${r.fim}`;

  const conflito = (r) =>
    S.reservas.find((x) => x.id !== r.id && APROV(x) && mesmaSala(x, r) && x.data === r.data &&
      min(x.inicio) < min(r.fim) && min(x.fim) > min(r.inicio));

  const vinculosSala = (s) => S.reservas.filter((r) => (PEND(r) || APROV(r)) && String(r.salaId) === String(s.id));

  const act = {

    menu: (v) => { S.menu = v === "1"; render(); },
    fechar: () => fecharModal(),
    fecharFundo: () => fecharModal(),

    /* ---- reservas / solicitações ---- */

    ver: (id) => { const r = reservaPorId(id); if (r) abrirModal(detalheReserva(r)); },

    pedirAprovar: (id) => {
      const r = reservaPorId(id); if (!r) return;
      const c = conflito(r);
      abrirModal(confirmar({
        titulo: "Aprovar solicitação?",
        corpo: `<p class="text-sm text-[#6B7280]">${esc(resumo(r))}</p>
                <p class="mt-2 text-sm text-[#6B7280]">O professor verá o status como <b>Aprovada</b>.</p>
                ${c ? aviso(`Já existe uma reserva aprovada neste horário (${esc(resumo(c))}). Resolva o conflito antes de aprovar.`, "rose") : ""}`,
        rotulo: "Aprovar", acao: "aprovar", v: r.id, k: "navy", bloqueado: !!c
      }));
    },

    aprovar: (id) => {
      const r = reservaPorId(id); if (!r) return;
      if (conflito(r)) { toast("Conflito de horário: reserva não aprovada.", "err"); return; }
      r.status = "Aprovada"; delete r.motivoRecusa;
      registrar("Aprovação", `Solicitação aprovada: ${resumo(r)}`);
      sync(() => adminApi.aprovarReserva(r.id));
      fecharModal(); render(); toast("Solicitação aprovada.");
    },

    pedirRecusar: (id) => {
      const r = reservaPorId(id); if (!r) return;
      abrirModal(modalBox("Recusar solicitação", `
        <p class="text-sm text-[#6B7280]">${esc(resumo(r))}</p>
        <form data-form="recusar" data-id="${esc(r.id)}" class="mt-4 space-y-4" novalidate>
          <label class="block">${lbl("Motivo da recusa", true)}
            <textarea name="motivo" rows="3" required placeholder="Explique ao professor por que a reserva foi recusada" class="${FLD}"></textarea>
          </label>
          ${erroForm}
          <div class="flex justify-end gap-2">
            ${btn("Voltar", { a: "fechar", k: "ghost" })}
            ${btn("Recusar solicitação", { type: "submit", i: "x-circle" })}
          </div>
        </form>`, { w: "max-w-md" }));
    },

    pedirCancelar: (id) => {
      const r = reservaPorId(id); if (!r) return;
      abrirModal(modalBox("Cancelar reserva", `
        <p class="text-sm text-[#6B7280]">${esc(resumo(r))}</p>
        <p class="mt-2 text-sm text-[#6B7280]">O horário será liberado e o professor verá o status como <b>Cancelada</b>.</p>
        <form data-form="cancelar" data-id="${esc(r.id)}" class="mt-4 space-y-4" novalidate>
          <label class="block">${lbl("Motivo do cancelamento (opcional)")}
            <textarea name="motivo" rows="2" class="${FLD}"></textarea>
          </label>
          <div class="flex justify-end gap-2">
            ${btn("Voltar", { a: "fechar", k: "ghost" })}
            ${btn("Cancelar reserva", { type: "submit", i: "trash-2" })}
          </div>
        </form>`, { w: "max-w-md" }));
    },

    /* ---- salas ---- */

    novaSala: () => abrirModal(formSala()),
    editarSala: (id) => { const s = salaPorId(id); if (s) abrirModal(formSala(s)); },

    pedirExcluirSala: (id) => {
      const s = salaPorId(id); if (!s) return;
      const n = vinculosSala(s).length;
      abrirModal(confirmar({
        titulo: "Excluir sala?",
        corpo: `<p class="text-sm text-[#6B7280]"><b>${esc(s.nome)}</b> (Bloco ${esc(s.bloco)}) deixará de aparecer para os professores. Esta ação não pode ser desfeita.</p>
                ${n ? aviso(`Há ${n} reserva(s) pendente(s) ou aprovada(s) nesta sala. Recuse ou cancele antes de excluir.`, "rose") : ""}`,
        rotulo: "Excluir sala", acao: "excluirSala", v: s.id, bloqueado: n > 0
      }));
    },

    excluirSala: (id) => {
      const s = salaPorId(id); if (!s || vinculosSala(s).length) return;
      S.salas = S.salas.filter((x) => x !== s);
      salvarSalasDemo();
      if (S.f.cal.sala === String(s.id)) S.f.cal.sala = "";
      registrar("Alteração", `Sala excluída: ${s.nome} (Bloco ${s.bloco})`);
      if (sessionStorage.getItem("admin_demo_mode") !== "true") sync(() => adminApi.excluirSala(s.id));
      fecharModal(); render(); toast("Sala excluída.");
    },

    /* ---- usuários ---- */

    verUsuario: (id) => { const u = usuarioPorId(id); if (u) abrirModal(usuarioVer(u)); },
    editarUsuario: (id) => { const u = usuarioPorId(id); if (u) abrirModal(usuarioForm(u)); },

    pedirToggleUsuario: (id) => {
      const u = usuarioPorId(id); if (!u) return;
      const des = ativo(u);
      abrirModal(confirmar({
        titulo: des ? "Desativar conta?" : "Ativar conta?",
        corpo: `<p class="text-sm text-[#6B7280]"><b>${esc(u.nome)}</b> ${des ? "não poderá mais acessar o sistema nem solicitar reservas." : "voltará a acessar o sistema normalmente."}</p>`,
        rotulo: des ? "Desativar" : "Ativar", acao: "toggleUsuario", v: u.id, k: des ? "primary" : "navy"
      }));
    },

    toggleUsuario: (id) => {
      const u = usuarioPorId(id); if (!u) return;
      u.ativo = !ativo(u);
      registrar("Alteração", `Conta ${u.ativo ? "ativada" : "desativada"}: ${u.nome}`);
      sync(() => adminApi.alterarAtivoUsuario(u.id, u.ativo));
      fecharModal(); render(); toast(u.ativo ? "Conta ativada." : "Conta desativada.");
    },

    /* ---- notificações ---- */

    notAba: (v) => { S.f.notificacoes.aba = v; render(); },

    lerNot: (id) => {
      const n = S.notificacoes.find((x) => String(x.id) === String(id)); if (!n) return;
      n.lida = true; sync(() => adminApi.marcarNotificacaoLida(n.id)); render();
    },

    lerTodas: () => {
      S.notificacoes.forEach((n) => (n.lida = true));
      sync(() => adminApi.marcarNotificacaoLida(null)); render();
    },

    notVer: (id) => {
      const n = S.notificacoes.find((x) => String(x.id) === String(id)); if (!n) return;
      n.lida = true; sync(() => adminApi.marcarNotificacaoLida(n.id));
      render(); act.ver(n.reservaId);
    },

    /* ---- calendário ---- */

    calModo: (v) => { S.f.cal.modo = v; render(); },
    calHoje: () => { S.f.cal.ref = hojeISO(); render(); },
    calDia: (v) => { S.f.cal.ref = v; S.f.cal.modo = "dia"; render(); },
    calNav: (v) => {
      const c = S.f.cal, n = Number(v);
      c.ref = c.modo === "mes" ? addMeses(c.ref, n) : addDias(c.ref, c.modo === "semana" ? 7 * n : n);
      render();
    },

    /* ---- sair ---- */

    pedirSair: () => abrirModal(confirmar({
      titulo: "Sair do painel?",
      corpo: '<p class="text-sm text-[#6B7280]">Você voltará para a tela de login administrativo.</p>',
      rotulo: "Sair", acao: "sair"
    })),

    sair: async () => {
      try { await adminApi.sair(); } catch (e) { console.error(e); }
      window.location.href = "admin_login.html";
    }
  };

  /* ================================================================
     FORMULÁRIOS
     ================================================================ */

  const mostrarErro = (form, t) => {
    const el = form.querySelector("[data-erro]");
    if (!el) return;
    el.textContent = t; el.classList.toggle("hidden", !t);
  };

  const forms = {

    sala: async (fd, form) => {
      const id = form.dataset.id;
      const arquivo = fd.get("imagemArquivo");
      let imagem = salaPorId(id)?.imagem || "";
      if (arquivo && arquivo.size) {
        if (!arquivo.type.startsWith("image/")) return mostrarErro(form, "Selecione um arquivo de imagem válido.");
        if (arquivo.size > 3 * 1024 * 1024) return mostrarErro(form, "A imagem deve ter no máximo 3 MB.");
        imagem = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(String(reader.result || ""));
          reader.onerror = () => reject(new Error("Falha ao ler a imagem."));
          reader.readAsDataURL(arquivo);
        }).catch(() => "");
        if (!imagem) return mostrarErro(form, "Não foi possível carregar a imagem. Tente novamente.");
      }
      const d = {
        imagem,
        nome: String(fd.get("nome") || "").trim(),
        bloco: fd.get("bloco"),
        piso: String(fd.get("piso") || "").trim(),
        capacidade: Number(fd.get("capacidade")),
        tipo: fd.get("tipo"),
        equipamentos: fd.getAll("equip"),
        descricao: String(fd.get("descricao") || "").trim()
      };

      if (!d.nome || !d.bloco || !d.piso || !d.tipo) return mostrarErro(form, "Preencha nome, bloco, andar e tipo de espaço.");
      if (!Number.isInteger(d.capacidade) || d.capacidade < 1) return mostrarErro(form, "A capacidade deve ser um número inteiro maior que zero.");
      if (S.salas.some((s) => String(s.id) !== id && s.bloco === d.bloco && s.nome.toLowerCase() === d.nome.toLowerCase()))
        return mostrarErro(form, "Já existe uma sala com esse nome neste bloco.");

      if (id) {
        const s = salaPorId(id);
        Object.assign(s, d);
        registrar("Alteração", `Sala editada: ${s.nome} (Bloco ${s.bloco})`);
        salvarSalasDemo();
        if (sessionStorage.getItem("admin_demo_mode") !== "true") sync(() => adminApi.editarSala(s.id, s));
        toast("Sala atualizada.");
      } else {
        const s = { id: uid(), ...d, disponivel: true }; // BACKEND: o id real vem do servidor
        S.salas.push(s);
        registrar("Alteração", `Sala cadastrada: ${s.nome} (Bloco ${s.bloco})`);
        salvarSalasDemo();
        if (sessionStorage.getItem("admin_demo_mode") !== "true") sync(() => adminApi.criarSala(s));
        toast("Sala cadastrada.");
      }
      fecharModal(); render();
    },

    recusar: (fd, form) => {
      const motivo = String(fd.get("motivo") || "").trim();
      if (!motivo) return mostrarErro(form, "Informe o motivo da recusa.");
      const r = reservaPorId(form.dataset.id); if (!r) return;
      r.status = "Recusada"; r.motivoRecusa = motivo;
      registrar("Recusa", `Solicitação recusada: ${resumo(r)}. Motivo: ${motivo}`);
      sync(() => adminApi.recusarReserva(r.id, motivo));
      fecharModal(); render(); toast("Solicitação recusada.");
    },

    cancelar: (fd, form) => {
      const r = reservaPorId(form.dataset.id); if (!r) return;
      const motivo = String(fd.get("motivo") || "").trim();
      r.status = "Cancelada"; if (motivo) r.motivoCancelamento = motivo;
      registrar("Cancelamento", `Reserva cancelada: ${resumo(r)}${motivo ? ". Motivo: " + motivo : ""}`);
      sync(() => adminApi.cancelarReserva(r.id, motivo));
      fecharModal(); render(); toast("Reserva cancelada.");
    },

    usuario: (fd, form) => {
      const u = usuarioPorId(form.dataset.id); if (!u) return;
      const nome = String(fd.get("nome") || "").trim(), email = String(fd.get("email") || "").trim();
      if (!nome || !email) return mostrarErro(form, "Nome e e-mail são obrigatórios.");
      if (!/^\S+@\S+\.\S+$/.test(email)) return mostrarErro(form, "Informe um e-mail válido.");
      Object.assign(u, {
        nome, email,
        cpf: fd.get("cpf"), nascimento: fd.get("nascimento"), telefone: fd.get("telefone"),
        matricula: fd.get("matricula"), cargo: fd.get("cargo")
      });
      registrar("Alteração", `Dados do usuário editados: ${u.nome}`);
      sync(() => adminApi.editarUsuario(u.id, u));
      fecharModal(); render(); toast("Usuário atualizado.");
    },

    config: (fd, form) => {
      const abertura = fd.get("abertura") || "", fechamento = fd.get("fechamento") || "";
      if (abertura && fechamento && min(fechamento) <= min(abertura))
        return mostrarErro(form, "O fechamento deve ser depois da abertura.");
      const c = {
        dias: fd.getAll("dias").map(Number), abertura, fechamento,
        duracaoMaxHoras: fd.get("duracaoMaxHoras") || "",
        antecedenciaMinHoras: fd.get("antecedenciaMinHoras") || "",
        antecedenciaMaxDias: fd.get("antecedenciaMaxDias") || ""
      };
      if (Object.entries(c).some(([k, v]) => !["dias", "abertura", "fechamento"].includes(k) && v !== "" && Number(v) < 0))
        return mostrarErro(form, "Os valores numéricos não podem ser negativos.");
      S.config = c;
      registrar("Alteração", "Configurações de reserva atualizadas");
      sync(() => adminApi.salvarConfig(c));
      mostrarErro(form, ""); render(); toast("Configurações salvas.");
    }
  };

  /* ================================================================
     EVENTOS
     ================================================================ */

  document.addEventListener("click", (e) => {
    const b = e.target.closest("[data-a]");
    if (!b || b.disabled) return;
    if (b.dataset.a === "fecharFundo" && e.target !== b) return; // clique dentro do modal
    const fn = act[b.dataset.a];
    if (typeof fn === "function") fn(b.dataset.v, b);
  });

  document.addEventListener("input", (e) => {
    const p = e.target.dataset?.f;
    if (!p) return;
    const [v, k] = p.split(".");
    S.f[v][k] = e.target.value;
    if (v === "cal") render(); else refreshList();
  });

  document.addEventListener("change", (e) => {
    if (e.target.matches('input[name="imagemArquivo"]')) {
      const arquivo = e.target.files?.[0];
      const form = e.target.closest("form");
      const preview = form?.querySelector("[data-preview-foto]");
      if (!preview) return;
      if (!arquivo) return;
      if (!arquivo.type.startsWith("image/") || arquivo.size > 3 * 1024 * 1024) {
        preview.innerHTML = '<p class="text-sm text-[#C8102E]">Escolha uma imagem válida de até 3 MB.</p>';
        preview.classList.remove("hidden");
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        preview.innerHTML = `<img src="${esc(String(reader.result || ""))}" alt="Prévia da foto da sala" class="h-36 w-full rounded-xl border border-[#E5E7EB] object-cover">`;
        preview.classList.remove("hidden");
      };
      reader.readAsDataURL(arquivo);
    }
  });

  document.addEventListener("submit", (e) => {
    const fn = forms[e.target.dataset?.form];
    if (!fn) return;
    e.preventDefault();
    fn(new FormData(e.target), e.target);
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && $("#modal-root").innerHTML) fecharModal();
  });

  window.addEventListener("hashchange", rota);

  /* ================================================================
     CARGA INICIAL
     ================================================================ */

  async function iniciar() {
    const modoDemo = sessionStorage.getItem("admin_demo_mode") === "true";
    if (modoDemo) {
      S.sessao = { nome: sessionStorage.getItem("admin_demo_nome") || "Administrador", papel: "admin" };
      // O modo de demonstração usa salas salvas localmente e não chama rotas protegidas.
      S.salas = carregarSalasDemo();
      rota();
      return;
    }

    try { S.sessao = await adminApi.sessao(); } catch { S.sessao = null; }
    if (!S.sessao || S.sessao.papel !== "admin") {
      S.sessao = null;
      window.location.replace("admin_login.html");
      return;
    }
    try {
      const [salas, reservas, usuarios, notificacoes, historico, config] = await Promise.all([
        adminApi.salas(), adminApi.reservas(), adminApi.usuarios(),
        adminApi.notificacoes(), adminApi.historico(), adminApi.config()
      ]);
      Object.assign(S, { salas: salas || [], reservas: reservas || [], usuarios: usuarios || [], notificacoes: notificacoes || [], historico: historico || [] });
      if (config) S.config = { ...S.config, ...config };
    } catch (err) { console.error("Falha ao carregar dados do painel:", err); }
    rota();
  }

  /* ================================================================
     API PÚBLICA (para o Back-End empurrar dados)
     ================================================================ */

  window.AdminApp = {
    // Ex.: AdminApp.setData({ reservas: [...] }) — gera notificações para
    // solicitações novas e para reservas cujo status mudou fora do painel.
    setData: (d = {}) => {
      if (d.reservas) {
        const antes = new Map(S.reservas.map((r) => [String(r.id), r.status]));
        d.reservas.forEach((r) => {
          const id = String(r.id);
          const nova = !antes.has(id) && PEND(r);
          const mudou = antes.has(id) && antes.get(id) !== r.status;
          if (nova || mudou) {
            S.notificacoes.unshift({
              id: uid(), tipo: nova ? "nova_solicitacao" : "alteracao", reservaId: r.id, lida: false,
              criadaEm: new Date().toISOString(),
              titulo: nova ? "Nova solicitação de reserva" : "Reserva alterada",
              mensagem: nova ? `${resumo(r)} aguarda análise.` : `${resumo(r)} agora está como ${r.status}.`
            });
          }
        });
      }
      ["salas", "reservas", "usuarios", "historico", "config"].forEach((k) => {
        if (d[k] !== undefined) S[k] = k === "config" ? { ...S.config, ...d[k] } : d[k];
      });
      if (d.notificacoes) S.notificacoes = d.notificacoes;
      render();
    },
    reload: iniciar
  };

  iniciar();
})();
