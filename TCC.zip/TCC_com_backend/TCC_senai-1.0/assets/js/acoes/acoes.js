    /* ================================================================
       AÇÕES
       ================================================================ */

    const act = {

      /* CAMERA */

      abrirCamera: async () => {

        try {

          const video =
            document.querySelector(
              "#cameraVideo"
            );

          const status =
            document.querySelector(
              "#cameraStatus"
            );

          const tirar =
            document.querySelector(
              '[data-a="tirarFoto"]'
            );

          if (
            !navigator.mediaDevices ||
            !navigator.mediaDevices
              .getUserMedia
          ) {

            if (status) {

              status.textContent =
                "Seu navegador não permite acesso à câmera. Use HTTPS ou localhost.";

              status.className =
                "text-center text-xs text-rose-700";
            }

            return;
          }

          const stream =
            await navigator.mediaDevices.getUserMedia(
              {
                video: {
                  facingMode: "user",
                  width: {
                    ideal: 720
                  },
                  height: {
                    ideal: 720
                  }
                },
                audio: false
              }
            );

          S.ui.cameraStream =
            stream;

          if (!video) return;

          video.srcObject =
            stream;

          video.classList.remove(
            "hidden"
          );

          if (tirar) {
            tirar.disabled = false;
          }

          if (status) {

            status.textContent =
              "Posicione o rosto dentro da câmera e tire a foto.";

            status.className =
              "text-center text-xs text-green-700";
          }

        } catch (err) {

          console.error(
            "Erro ao abrir câmera:",
            err
          );

          const status =
            document.querySelector(
              "#cameraStatus"
            );

          if (status) {

            status.textContent =
              "Não foi possível acessar a câmera. Verifique a permissão do navegador.";

            status.className =
              "text-center text-xs text-rose-700";
          }

        }
      },


      tirarFoto: () => {

        const video =
          document.querySelector(
            "#cameraVideo"
          );

        const canvas =
          document.querySelector(
            "#cameraCanvas"
          );

        if (
          !video ||
          !canvas ||
          !video.srcObject
        ) {
          return;
        }

        canvas.width =
          video.videoWidth || 720;

        canvas.height =
          video.videoHeight || 720;

        const ctx =
          canvas.getContext("2d");

        ctx.drawImage(
          video,
          0,
          0,
          canvas.width,
          canvas.height
        );

        S.f.fotoProfessor =
          canvas.toDataURL(
            "image/jpeg",
            0.85
          );

        if (S.ui.cameraStream) {

          S.ui.cameraStream
            .getTracks()
            .forEach(
              (track) =>
                track.stop()
            );

          S.ui.cameraStream =
            null;
        }

        video.srcObject = null;

        render();
      },


      refazerFoto: () => {

        if (S.ui.cameraStream) {

          S.ui.cameraStream
            .getTracks()
            .forEach(
              (track) =>
                track.stop()
            );

          S.ui.cameraStream =
            null;
        }

        S.f.fotoProfessor =
          "";

        render();

        setTimeout(() => {

          document
            .querySelector(
              '[data-a="abrirCamera"]'
            )
            ?.click();

        }, 100);

      },


      /* NAVEGAÇÃO */

      go: (v) => {

        /*
          Proteção extra para garantir
          que Minhas Reservas sempre abra.
        */

        go(v);
      },


      menu: (v) => {

        S.menu =
          v === "1";

        render();
      },


      modal: (v) => {

        S.ui.modal =
          v === "1";

        render();
      },


      bloco: (v) => {

        S.ui.bloco =
          v;

        S.ui.sala =
          null;

        render();
      },


      sala: (v) => {

        S.ui.sala =
          find(
            S.rooms,
            v
          );

        render();
      },


      verSala: (v) => {

        go("room", {
          room: find(
            S.rooms,
            v
          )
        });

      },


      verReserva: (v) => {

        go("reservation", {
          reservation:
            find(
              S.reservations,
              v
            )
        });

      },


      reservarSala: () => {

        go("new", {
          sala:
            S.sel.room
        });

      },


      tipo: (v) => {

        S.ui.tipo =
          v;

        render();
      },


      ntab: (v) => {

        S.ui.ntab =
          v;

        render();
      },


      ptab: (v) => {

        S.ui.ptab =
          v;

        S.ui.msg =
          null;

        render();
      },


      diaCalendario: (v) => {

        // Clicar em qualquer dia abre a nova reserva já com a data preenchida.
        // Se houver reservas, elas continuam acessíveis pelos botões vermelhos.
        go("new", { data: v });

      },


      mes: (v) => {

        const d =
          new Date(
            S.cal.y,
            S.cal.m +
            Number(v),
            1
          );

        S.cal = {
          y:
            d.getFullYear(),
          m:
            d.getMonth()
        };

        render();
      },


      mesHoje: () => {

        S.cal = {
          y:
            now.getFullYear(),
          m:
            now.getMonth()
        };

        render();
      },


      limpar: () => {

        S.f = {};

        render();
      },


      pw: (v, b) => {

        const i =
          b.parentElement.querySelector(
            "input"
          );

        if (!i) return;

        i.type =
          i.type ===
            "password"
            ? "text"
            : "password";
      },


      /* FOTO DE PERFIL */

      abrirSeletorFoto: () => {

        document
          .querySelector(
            "[data-foto-input]"
          )
          ?.click();

      },


      removerFotoPerfil: () => {

        S.ui.fotoPerfil = "";

        if (S.user) {
          S.user.foto = "";
        }

        S.ui.fotoMsg = null;

        render();
      },


      editar: () => {

        S.ui.edit =
          true;

        render();
      },


      cancelarEd: () => {

        CAMPOS.forEach(([k]) => {

          S.f["p_" + k] =
            S.user?.[k] ?? "";

        });

        S.ui.edit =
          false;

        render();
      },


      salvar: async () => {

        const dados = {};
        CAMPOS.forEach(([k]) => {
          if (S.f["p_" + k] !== undefined) dados[k] = S.f["p_" + k];
        });
        dados.foto = S.user?.foto || "";

        try {
          S.user = await api.salvarPerfil(dados);
          S.ui.edit = false;
          S.ui.msg = ["ok", "Perfil atualizado."];
        } catch (e) {
          S.ui.msg = ["err", e.message];
        }

        render();
      },


      cancelarReserva: async () => {

        const r = S.sel.reservation;

        try {
          if (r) {
            await api.cancelarReserva(r.id);
            r.status = "Cancelada";
          }
        } catch (e) {
          alert(e.message);
        }

        S.ui.modal =
          false;

        render();
      },


      lidas: () => {

        api.marcarLidas().catch(console.error);

        S.notifications.forEach(
          (n) => {
            n.lida = true;
          }
        );

        render();
      }

    };
