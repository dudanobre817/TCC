/* LOGIN ADMINISTRATIVO — validação temporária somente no front-end.
   A autenticação real será integrada ao banco posteriormente. */
(() => {
  const $ = (s) => document.querySelector(s);
  const msg = (t) => {
    const el = $("#admin-msg");
    el.textContent = t;
    el.classList.toggle("hidden", !t);
  };

  if (window.lucide) lucide.createIcons();

  $("#admin-pw").addEventListener("click", () => {
    const input = $("#admin-senha");
    input.type = input.type === "password" ? "text" : "password";
  });

  $("#form-admin").addEventListener("submit", (e) => {
    e.preventDefault();

    const email = $("#admin-email").value.trim();
    const senha = $("#admin-senha").value.trim();

    if (!email || !senha) {
      msg("Os campos de login e senha são obrigatórios.");
      if (!email) $("#admin-email").focus();
      else $("#admin-senha").focus();
      return;
    }

    // Acesso de demonstração: exige campos preenchidos, mas ainda não valida credenciais.
    msg("");
    sessionStorage.setItem("admin_demo_mode", "true");
    sessionStorage.setItem("admin_demo_nome", email || "Administrador");
    window.location.href = "admin.html";
  });
})();
