    /* ================================================================
       CARD DE SALA
       ================================================================ */

    const roomCard = (r, a, sel) => `
      <button
        type="button"
        data-a="${a}"
        data-v="${esc(r.id)}"
        class="${CARD} overflow-hidden text-left transition hover:-translate-y-0.5 hover:shadow-md ${sel ? "ring-2 ring-[#C8102E]" : ""
      }"
      >

        <div class="relative h-32 bg-[#F8F9FA]">

          ${r.imagem
        ? `
                <img
                  src="${esc(r.imagem)}"
                  alt="${esc(r.nome)}"
                  class="h-full w-full object-cover"
                >
              `
        : ""
      }

          <span class="absolute right-2 top-2">
            ${badge(r.disponivel ? "Disponível" : "Ocupado")}
          </span>

        </div>

        <div class="p-3">

          <p class="font-bold text-[#A80D25]">
            ${esc(r.nome)}
          </p>

          <p class="text-xs text-[#6B7280]">
            Capacidade: ${esc(r.capacidade)} pessoas
          </p>

          <p class="text-xs font-semibold text-[#1E2A78]">
            Bloco ${esc(r.bloco)} · ${esc(r.piso)}
          </p>

        </div>

      </button>
    `;


    const notifItem = (n) => `
      <div class="flex gap-3 rounded-xl border p-3 ${n.lida
        ? "border-[#E5E7EB] bg-white"
        : "border-red-200 bg-red-50"
      }">

        <span class="mt-0.5 text-[#C8102E]">
          ${ic("bell", "w-[18px] h-[18px]")}
        </span>

        <div>

          <p class="text-sm font-semibold">
            ${esc(n.titulo)}
          </p>

          <p class="text-sm text-[#6B7280]">
            ${esc(n.mensagem)}
          </p>

          <p class="mt-1 text-xs text-[#9CA3AF]">
            ${esc(n.criadaEm)}
          </p>

        </div>

      </div>
    `;


    const table = (cols, rows, emptyHtml) => `
      <div class="overflow-x-auto">

        <table class="w-full min-w-[720px] text-sm">

          <thead>
            <tr class="bg-red-50 text-left text-xs text-[#A80D25]">

              ${cols
        .map(
          (c) =>
            `<th class="px-3 py-2.5 font-semibold">${c[0]}</th>`
        )
        .join("")}

            </tr>
          </thead>

          <tbody>

            ${rows
        .map(
          (r) => `
                  <tr class="border-b border-[#E5E7EB] hover:bg-[#F8F9FA]">

                    ${cols
              .map(
                (c) =>
                  `<td class="px-3 py-2.5">${c[1](r)}</td>`
              )
              .join("")}

                  </tr>
                `
        )
        .join("")}

          </tbody>

        </table>

        ${rows.length ? "" : emptyHtml}

      </div>
    `;


    const timeline = (items = []) =>
      items.length
        ? `
          <ol class="space-y-3 border-l-2 border-[#E5E7EB] pl-4">

            ${items
          .map(
            (h) => `
                  <li class="relative text-sm">

                    <span class="absolute -left-[22px] top-1 h-3 w-3 rounded-full bg-[#C8102E]"></span>

                    <b class="text-[#1E2A78]">
                      ${esc(h.status)}
                    </b>:
                    ${esc(h.em)}

                  </li>
                `
          )
          .join("")}

          </ol>
        `
        : `<p class="text-sm text-[#6B7280]">Nenhum histórico disponível.</p>`;


    const blockSelector = (sel) => `
      <div class="grid grid-cols-3 gap-3">

        ${BLOCOS.map(
      (b) => `
            <button
              type="button"
              data-a="bloco"
              data-v="${b}"
              class="${CARD} flex flex-col items-center gap-1 p-4 transition hover:shadow-md ${sel === b
          ? "bg-red-50 ring-2 ring-[#C8102E]"
          : ""
        }"
            >

              <span class="text-[#C8102E]">
                ${ic("building-2", "w-6 h-6")}
              </span>

              <span class="font-bold">
                BLOCO ${b}
              </span>

              <span class="text-xs text-[#6B7280]">
                ${sel === b ? "Selecionado" : "Selecionar"}
              </span>

            </button>
          `
    ).join("")}

      </div>
    `;
