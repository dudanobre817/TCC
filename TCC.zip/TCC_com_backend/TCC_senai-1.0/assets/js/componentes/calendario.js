    /* ================================================================
       CALENDÁRIO NOVO
       ================================================================ */

    const calendar = () => {

      const y = S.cal.y;
      const m = S.cal.m;

      const primeiroDia = new Date(y, m, 1);
      const ultimoDia = new Date(y, m + 1, 0);

      const quantidadeDias = ultimoDia.getDate();

      /*
        Domingo = 0
        Segunda = 1
        ...
        Para o calendário começar na segunda:
        0 vira 6
        1 vira 0
        etc.
      */

      const inicio = (primeiroDia.getDay() + 6) % 7;

      const reservasMes = S.reservations.filter((r) => {

        if (!r.data || r.status === "Cancelada") {
          return false;
        }

        const d = new Date(r.data + "T00:00:00");

        return (
          d.getFullYear() === y &&
          d.getMonth() === m
        );
      });

      let dias = "";

      for (let i = 0; i < inicio; i++) {

        dias += `
          <div class="min-h-[105px] rounded-xl bg-[#F8F9FA]"></div>
        `;
      }

      for (let dia = 1; dia <= quantidadeDias; dia++) {

        const dataISO =
          `${y}-${String(m + 1).padStart(2, "0")}-${String(dia).padStart(2, "0")}`;

        const reservas = reservasMes.filter(
          (r) => r.data === dataISO
        );

        const hoje =
          dia === now.getDate() &&
          m === now.getMonth() &&
          y === now.getFullYear();

        dias += `
          <button
            type="button"
            data-a="diaCalendario"
            data-v="${dataISO}"
            class="group min-h-[105px] w-full rounded-xl border text-left ${hoje
            ? "border-[#C8102E] bg-red-50 ring-1 ring-[#C8102E]"
            : "border-[#E5E7EB] bg-white"
          } p-2 transition hover:-translate-y-0.5 hover:border-[#C8102E] hover:shadow-md focus:outline-none focus:ring-2 focus:ring-[#C8102E]/30"
            title="${reservas.length ? `Abrir ${reservas.length} reserva(s)` : "Clique para criar uma reserva nesta data"}"
          >

            <div class="mb-2 flex items-center justify-between">

              <span
                class="flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold ${hoje
            ? "bg-[#C8102E] text-white"
            : "text-[#374151]"
          }"
              >
                ${dia}
              </span>

              ${reservas.length
            ? `
                    <span class="rounded-full bg-red-100 px-2 py-0.5 text-[10px] font-bold text-[#C8102E]">
                      ${reservas.length}
                    </span>
                  `
            : ""
          }

            </div>

            <div class="space-y-1">

              ${reservas.length
            ? reservas
              .slice(0, 2)
              .map(
                (r) => `
                          <button
                            type="button"
                            data-a="verReserva"
                            data-v="${esc(r.id)}"
                            class="block w-full truncate rounded-lg bg-[#C8102E] px-2 py-1.5 text-left text-[10px] font-semibold text-white hover:bg-[#A80D25]"
                            title="${esc(r.espaco)}"
                          >
                            ${esc(r.espaco)}
                          </button>
                        `
              )
              .join("")
            : `
                    <span class="inline-flex items-center gap-1 rounded-lg px-2 py-1.5 text-[10px] text-[#9CA3AF] transition group-hover:bg-red-50 group-hover:text-[#C8102E]">
                      ${ic("plus", "w-3 h-3")} Clique para reservar
                    </span>
                  `
          }

              ${reservas.length > 2
            ? `
                    <span class="block text-[10px] font-semibold text-[#6B7280]">
                      +${reservas.length - 2} reserva(s)
                    </span>
                  `
            : ""
          }

            </div>

          </button>
        `;
      }

      return `
        <div class="${CARD} overflow-hidden">

          <div class="flex flex-wrap items-center justify-between gap-3 border-b border-[#E5E7EB] p-5">

            <div>

              <p class="text-xs font-semibold uppercase tracking-wide text-[#6B7280]">
                Calendário de reservas
              </p>

              <h2 class="mt-1 text-xl font-bold text-[#A80D25]">
                ${MESES_COMPLETOS[m]} ${y}
              </h2>

            </div>

            <div class="flex items-center gap-2">

              ${btn("", {
        a: "mes",
        v: "-1",
        i: "chevron-left",
        k: "outline",
        c: "!px-3"
      })}

              ${btn("Hoje", {
        a: "mesHoje",
        k: "ghost",
        c: "!px-3"
      })}

              ${btn("", {
        a: "mes",
        v: "1",
        i: "chevron-right",
        k: "outline",
        c: "!px-3"
      })}

            </div>

          </div>

          <div class="calendar-scroll overflow-x-auto p-4">

            <div class="min-w-[720px]">

              <div class="mb-2 grid grid-cols-7 gap-2">

                ${[
          "Segunda",
          "Terça",
          "Quarta",
          "Quinta",
          "Sexta",
          "Sábado",
          "Domingo"
        ]
          .map(
            (d) => `
                      <div class="py-2 text-center text-xs font-bold uppercase text-[#6B7280]">
                        ${d}
                      </div>
                    `
          )
          .join("")}

              </div>

              <div class="grid grid-cols-7 gap-2">
                ${dias}
              </div>

            </div>

          </div>

          <div class="flex flex-wrap gap-4 border-t border-[#E5E7EB] px-5 py-3 text-xs text-[#6B7280]">

            <div class="flex items-center gap-2">
              <span class="h-3 w-3 rounded-full bg-[#C8102E]"></span>
              Reserva
            </div>

            <div class="flex items-center gap-2">
              <span class="h-3 w-3 rounded-full border border-[#C8102E] bg-red-50"></span>
              Hoje
            </div>

          </div>

        </div>
      `;
    };
