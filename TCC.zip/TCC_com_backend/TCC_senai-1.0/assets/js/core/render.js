    /* ================================================================
       RENDER
       ================================================================ */

    function render() {

      const k =
        document.activeElement?.dataset?.k;

      const pagina =
        S.page === "login"
          ? login()
          : S.page === "register"
            ? register()
            : layout(
              views[S.page]
                ? views[S.page]()
                : views.home()
            );

      $("#app").innerHTML = pagina;

      if (
        window.lucide &&
        typeof lucide.createIcons ===
        "function"
      ) {
        lucide.createIcons();
      }

      if (k) {

        const el = $(
          `[data-k="${k}"]`
        );

        if (el) {

          el.focus();

          try {
            el.setSelectionRange(
              el.value.length,
              el.value.length
            );
          } catch { }

        }
      }
    }
