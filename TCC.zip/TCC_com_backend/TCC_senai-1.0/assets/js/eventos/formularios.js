    /* ================================================================
       FORMULÁRIOS
       ================================================================ */

    const forms = {

      login: async () => {

        try {
          await api.login(S.f.email, S.f.senha);
          go("home");
        } catch (e) {
          S.ui.msg = ["err", e.message];
          render();
        }

      },


      cadastro: async () => {

        if (S.f.senha !== S.f.conf) {
          S.ui.msg = ["err", "As senhas não coincidem."];
          render();
          return;
        }

        try {
          await api.cadastro({
            nome: S.f.nome, email: S.f.email, cpf: S.f.cpf, nasc: S.f.nasc,
            tel: S.f.tel, mat: S.f.mat, senha: S.f.senha
          });
          S.ui.msg = ["ok", "Conta criada! Agora é só fazer login."];
        } catch (e) {
          S.ui.msg = ["err", e.message];
        }

        render();

      },


      nova: async () => {

        if (
          !S.f.fotoProfessor
        ) {

          S.ui.msg = [
            "err",
            "É obrigatório tirar uma foto do rosto antes de solicitar a reserva."
          ];

          render();

          return;
        }


        if (!S.ui.sala) {

          S.ui.msg = [
            "err",
            "Selecione uma sala antes de continuar."
          ];

          render();

          return;
        }


        if (
          !S.f.ini ||
          !S.f.fim
        ) {

          S.ui.msg = [
            "err",
            "Informe o horário inicial e final."
          ];

          render();

          return;
        }


        if (
          S.f.fim <=
          S.f.ini
        ) {

          S.ui.msg = [
            "err",
            "O horário final deve ser depois do inicial."
          ];

          render();

          return;
        }


        /*
          BACKEND:

          POST /reservas

          {
            salaId: S.ui.sala.id,
            data: S.f.data,
            ini: S.f.ini,
            fim: S.f.fim,
            turma: S.f.turma,
            fin: S.f.fin,
            pes: S.f.pes,
            obs: S.f.obs,
            fotoProfessor: S.f.fotoProfessor
          }
        */

        try {
          const nova = await api.novaReserva({
            salaId: S.ui.sala.id,
            data: S.f.data,
            ini: S.f.ini,
            fim: S.f.fim,
            turma: S.f.turma,
            fin: S.f.fin,
            pes: S.f.pes,
            obs: S.f.obs,
            fotoProfessor: S.f.fotoProfessor
          });
          S.reservations.unshift(nova);
          S.ui.msg = ["ok", "Solicitação enviada! Ela está em análise."];
        } catch (e) {
          S.ui.msg = ["err", e.message];
        }

        render();
      },


      senha: async () => {

        if (S.f.n !== S.f.c) {
          S.ui.msg = ["err", "As senhas não coincidem."];
          render();
          return;
        }

        try {
          await api.trocarSenha(S.f.a, S.f.n);
          S.ui.msg = ["ok", "Senha alterada com sucesso."];
        } catch (e) {
          S.ui.msg = ["err", e.message];
        }

        render();
      }

    };


    document.addEventListener(
      "submit",
      (e) => {

        const f =
          forms[
          e.target.dataset.form
          ];

        if (f) {

          e.preventDefault();

          f();

        }

      }
    );
