    /* ================================================================
       CLIQUES
       ================================================================ */

    document.addEventListener(
      "click",
      (e) => {

        const b =
          e.target.closest(
            "[data-a]"
          );

        if (!b) {
          return;
        }

        if (
          b.disabled ||
          b.hasAttribute("disabled")
        ) {
          return;
        }

        const acao =
          b.dataset.a;

        if (
          act[acao] &&
          typeof act[acao] ===
          "function"
        ) {

          act[acao](
            b.dataset.v,
            b
          );

        }

      }
    );
